# Reproduction — Problem v86 Performance Evidence Pack

Exact commands and working directories to independently re-verify the evidence in
this pack. All paths below assume this pack has been unzipped to a directory named
`PROBLEM-V86-PERFORMANCE-EVIDENCE-PACK`; `cd` into it first.

## 1. Verify package integrity

```bash
cd PROBLEM-V86-PERFORMANCE-EVIDENCE-PACK
sha256sum -c SHA256SUMS.txt
```
Expected: every line reports `OK`.

## 2. Verify the repaired file's identity

```bash
sha256sum Problem-v86-DARK-ONLY-PERFORMANCE-REPAIRED.html
wc -l -c Problem-v86-DARK-ONLY-PERFORMANCE-REPAIRED.html
```
Expected: `01eca32b5223a7097b7a5798688254e772a2fb5703bad0bb6688f7dd07ad66c1`, 45,668 lines,
3,050,127 bytes (see `CONTEXT-CERTIFICATE-v86.md` for the original's pre-repair
identity: SHA-256 `7608fa8bede185c28e4cc905cc8f60e700fdee5d3bd1f7660c66280b9c28bb26`,
45,668 lines, 3,049,614 bytes).

## 3. Inspect the exact change set

```bash
cat original-vs-repaired.diff
```
This is the full unified diff between the authorized original and the repaired
file (104 lines). No other content differs.

## 4. Re-run static syntax verification (Node.js required, any recent version)

```bash
node -e "
const fs = require('fs');
const html = fs.readFileSync('Problem-v86-DARK-ONLY-PERFORMANCE-REPAIRED.html', 'utf8');
const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g;
let m, i = 0;
fs.mkdirSync('/tmp/v86-script-check', {recursive:true});
while((m = re.exec(html))){ i++; fs.writeFileSync('/tmp/v86-script-check/script_'+i+'.js', m[1]); }
console.log('extracted', i, 'script blocks (expect 19)');
"
for f in /tmp/v86-script-check/script_*.js; do node --check "$f" || echo "FAIL: $f"; done
echo "if nothing printed FAIL above, all script blocks pass"
```
Compare against `test-results/node-check-all-scripts.log` for the recorded result
(19/19 pass, Node v22.22.2).

## 5. Re-run the automated runtime checks (requires Playwright + a Chromium binary)

```bash
npm install playwright   # or ensure a global Playwright install is on NODE_PATH
npx playwright install chromium   # skip if a Chromium binary is already available
node test-results/gate-c-runtime.js > /tmp/gate-c-rerun.json
```

Note: `test-results/gate-c-runtime.js` loads
`Problem-v86-DARK-ONLY-PERFORMANCE-REPAIRED.html` via a relative `file://` path
constructed from `path.resolve('/home/user/coza-problem/Problem-v86-DARK-ONLY.html')`
— **edit the `FILE` constant near the top of the script to point at this pack's copy
of `Problem-v86-DARK-ONLY-PERFORMANCE-REPAIRED.html`** before re-running outside the
original session's container (the hardcoded absolute path will not exist on another
machine). This is a known limitation of the delivered script, not a hidden change —
see `EVIDENCE-PACK-INDEX.md`.

Compare `/tmp/gate-c-rerun.json` against `test-results/gate-c-runtime-output.json`
(the originally captured run). Expect, for every tier (`high`/`mid`/`low`/`auto`):
- `pageErrors: []`
- `tierForcePersistence.heldForced: true` when a tier is forced
- `brandReveal.finishedEarlyDueToHidden: true`
- `devtoolsInterval: {"beforeHidden":true,"duringHidden":false,"afterRestore":true}`

## 6. What this reproduction does NOT cover

Steps 1-5 are headless/desktop checks. They do not measure real-device frame rate,
thermal behavior, or battery impact on Samsung A05s or Oppo A55 — neither device was
available in the original session, and none of the steps above substitute for that
gate. See `PERFORMANCE-VERIFICATION-v86.md`, "Gate D", for the exact on-device
procedure that still needs to be run.
