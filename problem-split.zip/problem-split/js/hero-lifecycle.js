//  HeroLife — Central lifecycle manager for all hero engines
//  المصدر الوحيد للحقيقة: مين شغال، إمتى يوقف، إمتى يكمل.
//  بيحل 3 مشاكل:
//   1) animation تفضل شغالة في صفحة تانية (مش landing)
//   2) أكتر من engine شغال في نفس الوقت → تعليق على iPhone 11 / OPPO A55
//   3) animation شغالة والموبايل نايم / التطبيق في الخلفية → استهلاك بطارية
// ════════════════════════════════════════════════════════════
window.HeroLife = (function(){
  'use strict';

  var current = null;        // اسم النسخة المختارة حالياً: 'person'|'1'|'2'|'3'|'4'|'5'
  var pageActive = true;     // هل احنا في صفحة landing؟
  var docVisible = true;     // هل الصفحة/التطبيق ظاهر (مش في الخلفية)؟
  var running = null;        // اسم الـ engine الفعلي اللي شغال دلوقتي (أو null)

  // خريطة كل engine وطريقة تشغيله/إيقافه — مكان واحد لو اتغير أي حاجة
  function engines(){
    return {
      'person': {
        start: function(){
          if(window.SeekerCine && SeekerCine.start) SeekerCine.start();
          else if(typeof window.updateVPerson==='function') window.updateVPerson();
        },
        stop: function(){ if(window.SeekerCine && SeekerCine.stop) SeekerCine.stop(); }
      },
      '2': {
        start: function(){ if(typeof LJ!=='undefined' && LJ.start) LJ.start(); },
        stop:  function(){ if(typeof LJ!=='undefined' && LJ.stop)  LJ.stop(); }
      },
      '3': {
        start: function(){ if(typeof V3!=='undefined' && V3.start) V3.start(); },
        stop:  function(){ if(typeof V3!=='undefined' && V3.stop)  V3.stop(); }
      },
      '4': {
        start: function(){ if(typeof V4!=='undefined' && V4.start) V4.start(); },
        stop:  function(){ if(typeof V4!=='undefined' && V4.stop)  V4.stop(); }
      },
      '5': {
        start: function(){ if(typeof V5!=='undefined' && V5.start) V5.start(); },
        stop:  function(){ if(typeof V5!=='undefined' && V5.stop)  V5.stop(); }
      }
      // V1 (الـ SVG) مالهوش start/stop — بيتحكم فيه CSS + perf.isVisible
    };
  }

  // أوقف كل الـ engines بدون استثناء — التأكيد إن مفيش حاجة شغالة في الخلفية
  function stopAll(){
    var e = engines();
    for(var k in e){ try{ e[k].stop(); }catch(err){} }
    running = null;
  }

  // الدالة المركزية: تحسب لو المفروض حاجة تشتغل دلوقتي، وتزامن الواقع مع القرار
  function sync(){
    // الشرط الوحيد للتشغيل: في صفحة landing + الصفحة ظاهرة + في نسخة canvas مختارة
    var shouldRun = pageActive && docVisible && current && current!=='1';

    if(shouldRun){
      // لو اللي شغال مش هو المختار → اوقف الكل وشغّل المختار بس (single-active)
      if(running !== current){
        stopAll();
        var e = engines()[current];
        if(e){ try{ e.start(); running = current; }catch(err){} }
      }
    } else {
      // مفيش حاجة المفروض تشتغل → اوقف كل شيء
      if(running !== null) stopAll();
    }
  }

  return {
    // بيتنده من setHeroVisual لما المستخدم يغيّر النسخة
    select: function(v){ current = String(v); sync(); },
    // بيتنده من showPage: true لو landing، false لأي صفحة تانية
    setPage: function(isLanding){ pageActive = !!isLanding; sync(); },
    // بيتنده من visibilitychange
    setVisible: function(vis){ docVisible = !!vis; sync(); },
    // للطوارئ / debugging
    stopAll: stopAll,
    _state: function(){ return {current:current, pageActive:pageActive, docVisible:docVisible, running:running}; }
  };
})();