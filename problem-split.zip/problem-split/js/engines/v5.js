const V5 = (function(){
  let _raf=null,_alive=false,_t0=0,_loopCount=0;
  let _tapFlash=0,_tapX=0,_tapY=0;
  const TOTAL=30000;

  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const lerp=(a,b,t)=>a+(b-a)*t;
  const eio=t=>t<0.5?2*t*t:1-Math.pow(-2*t+2,2)/2;
  const pp=(t,s,e)=>clamp((t-s)/(e-s),0,1);

  // ── Chapters ──────────────────────────────────────────────
  const CHS=[
    {t:0,     n:'',          txt:null},
    {t:3000,  n:'alone',     txt:'they said they cared'},
    {t:7000,  n:'the book',  txt:'then you found this'},
    {t:11500, n:'the maze',  txt:'every answer was in the maze'},
    {t:17000, n:'choosing',  txt:'you started choosing yourself'},
    {t:21000, n:'the ones',  txt:'and the right ones stayed'},
    {t:26000, n:'',          txt:null},
  ];

  // ── Draw the girl character ────────────────────────────────
  function drawChar(ctx,cx,cy,sc,now,slump,smile,eyeOffX,eyeOffY,breath){
    // ═══ THE GIRL — long flowing hair · anime eyes · Gen Z ═══
    // مبنية من الصفر لتطابق المرجع: رأس بيضاوي طويل، شعر منسدل طويل
    // عيون لوزية واسعة بحلقات، جسم مستطيل، أصابع مفرودة، قدمان بيضاويتان
    const I='rgba(225,235,248,', C='rgba(232,242,255,', S=sc;
    const eox=eyeOffX||0, eoy=eyeOffY||0;
    const br=(breath||0)*S*.014;
    const f=Math.sin(now*1.4)*2.6;

    ctx.save(); ctx.translate(0,f);
    ctx.lineCap='round'; ctx.lineJoin='round';

    // ── الأبعاد ──
    const hy = cy - S*.46 + slump*S*.10;   // مركز الرأس (ينخفض مع الانحناء)
    const hrx = S*.215, hry = S*.285;      // رأس بيضاوي طويل
    const neckB = hy + hry + S*.075;       // نهاية الرقبة
    const tw = S*.215;                     // نصف عرض الجذع (فوق)
    const th = S*.40;                      // طول الجذع
    const hipY = neckB + th;

    // ═══ الشعر الخلفي الطويل (ينسدل على اليسار حتى منتصف الجذع) ═══
    const sway = Math.sin(now*.75)*.022*S;
    // الخصلة الكبرى — من التاج تنحني يساراً وتنزل طويلاً
    ctx.strokeStyle=I+'0.52)'; ctx.lineWidth=S*.026;
    ctx.beginPath();
    ctx.moveTo(cx+hrx*.05, hy-hry*1.02);
    ctx.bezierCurveTo(
      cx-hrx*1.85, hy-hry*.45,
      cx-hrx*1.55+sway, hy+hry*.85,
      cx-hrx*1.28+sway, hy+S*.62);
    ctx.stroke();
    // خصلة داخلية موازية أرفع
    ctx.strokeStyle=I+'0.36)'; ctx.lineWidth=S*.015;
    ctx.beginPath();
    ctx.moveTo(cx-hrx*.12, hy-hry*.98);
    ctx.bezierCurveTo(
      cx-hrx*1.5, hy-hry*.3,
      cx-hrx*1.3+sway, hy+hry*.7,
      cx-hrx*1.08+sway, hy+S*.46);
    ctx.stroke();

    // ═══ الرأس (بيضاوي طويل) ═══
    ctx.strokeStyle=I+'0.88)'; ctx.lineWidth=S*.017;
    ctx.fillStyle='rgba(4,6,8,0.82)';
    ctx.beginPath();
    ctx.ellipse(cx, hy, hrx, hry, 0, 0, Math.PI*2);
    ctx.fill(); ctx.stroke();

    // ═══ شعر مقدّم — كنسة فوق التاج لليمين (زي المرجع) ═══
    ctx.strokeStyle=I+'0.60)'; ctx.lineWidth=S*.020;
    ctx.beginPath();
    ctx.moveTo(cx-hrx*.72, hy-hry*.52);
    ctx.quadraticCurveTo(cx-hrx*.1, hy-hry*1.32, cx+hrx*.88, hy-hry*.62);
    ctx.stroke();
    // كنسة داخلية أقصر
    ctx.strokeStyle=I+'0.42)'; ctx.lineWidth=S*.013;
    ctx.beginPath();
    ctx.moveTo(cx-hrx*.25, hy-hry*1.0);
    ctx.quadraticCurveTo(cx+hrx*.45, hy-hry*1.22, cx+hrx*.92, hy-hry*.78);
    ctx.stroke();

    // ═══ العيون — لوزية anime واسعة بحلقات قزحية ═══
    const eyeY = hy - hry*.02;
    const eyeW = hrx*.52, eyeHbase = hrx*.30;
    [-0.52, 0.52].forEach((exm, ei)=>{
      const ecx = cx + exm*hrx + eox;
      const ecy = eyeY + eoy;
      const blink = 0.86 + Math.sin(now*2.0 + ei*1.2)*.09;
      const eh = eyeHbase*blink;

      // توهج خلف العين
      ctx.save(); ctx.filter='blur(3px)';
      ctx.fillStyle='rgba(232,242,255,0.07)';
      ctx.beginPath();
      ctx.ellipse(ecx, ecy, eyeW*1.25, eh*1.5, 0, 0, Math.PI*2);
      ctx.fill(); ctx.restore();

      // اللوزة (مملوءة داكن)
      ctx.beginPath();
      ctx.moveTo(ecx-eyeW, ecy);
      ctx.quadraticCurveTo(ecx, ecy-eh*1.7, ecx+eyeW, ecy);
      ctx.quadraticCurveTo(ecx, ecy+eh*1.15, ecx-eyeW, ecy);
      ctx.closePath();
      ctx.fillStyle='rgba(4,6,8,0.88)'; ctx.fill();
      // الجفن العلوي أوضح
      ctx.beginPath();
      ctx.moveTo(ecx-eyeW, ecy);
      ctx.quadraticCurveTo(ecx, ecy-eh*1.7, ecx+eyeW, ecy);
      ctx.strokeStyle=I+'0.92)'; ctx.lineWidth=S*.020; ctx.stroke();
      // الجفن السفلي أخف
      ctx.beginPath();
      ctx.moveTo(ecx-eyeW, ecy);
      ctx.quadraticCurveTo(ecx, ecy+eh*1.15, ecx+eyeW, ecy);
      ctx.strokeStyle=I+'0.40)'; ctx.lineWidth=S*.011; ctx.stroke();

      // حلقات القزحية المتراكزة (زي المرجع)
      const ir = eh*1.0;
      [ir, ir*.66, ir*.36].forEach((r,ri)=>{
        ctx.strokeStyle=I+[.46,.32,.22][ri]+')'; ctx.lineWidth=S*.0075;
        ctx.beginPath(); ctx.arc(ecx, ecy+eh*.06, r, 0, Math.PI*2); ctx.stroke();
      });
      // بؤبؤ مضيء
      ctx.save();
      ctx.shadowColor=C+'0.8)'; ctx.shadowBlur=S*.05;
      ctx.fillStyle=C+'0.95)';
      ctx.beginPath(); ctx.arc(ecx, ecy+eh*.06, ir*.20, 0, Math.PI*2); ctx.fill();
      ctx.restore();
      // لمعة
      ctx.fillStyle='rgba(255,255,255,0.85)';
      ctx.beginPath();
      ctx.ellipse(ecx+eyeW*.30, ecy-eh*.42, ir*.15, ir*.09, -.3, 0, Math.PI*2);
      ctx.fill();
    });

    // ═══ الأنف (خط صغير زي المرجع) ═══
    ctx.strokeStyle=I+'0.20)'; ctx.lineWidth=S*.009;
    ctx.beginPath();
    ctx.moveTo(cx+eox*.5, eyeY+hry*.34);
    ctx.lineTo(cx+S*.014+eox*.5, eyeY+hry*.46);
    ctx.stroke();

    // ═══ الفم — ابتسامة تتسع مع smile ═══
    const smY = eyeY + hry*.66;
    const smCurve = lerp(S*.008, S*.05, smile);
    ctx.strokeStyle=I+'0.55)'; ctx.lineWidth=S*.013;
    ctx.beginPath();
    ctx.moveTo(cx-S*.062, smY);
    ctx.quadraticCurveTo(cx, smY+smCurve, cx+S*.062, smY);
    ctx.stroke();

    // ═══ الرقبة ═══
    ctx.strokeStyle=I+'0.60)'; ctx.lineWidth=S*.015;
    ctx.beginPath(); ctx.moveTo(cx-S*.020, hy+hry*.96); ctx.lineTo(cx-S*.020, neckB); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx+S*.020, hy+hry*.96); ctx.lineTo(cx+S*.020, neckB); ctx.stroke();

    // ═══ الجذع المستطيل (يتنفس + ينحني مع slump) ═══
    const shY = neckB + br;                 // الكتف (يتحرك مع التنفس)
    const slumpIn = slump*S*.03;            // الانحناء يضيّق الكتفين شوية
    ctx.strokeStyle=I+'0.64)'; ctx.lineWidth=S*.017;
    ctx.fillStyle='rgba(4,6,8,0.5)';
    ctx.beginPath();
    ctx.moveTo(cx-tw+slumpIn, shY);
    ctx.lineTo(cx+tw-slumpIn, shY);
    ctx.lineTo(cx+tw*.78, hipY);
    ctx.lineTo(cx-tw*.78, hipY);
    ctx.closePath();
    ctx.fill(); ctx.stroke();

    // ═══ الذراعان — منحنيتان للخارج، اليسرى أطول (زي المرجع) ═══
    const armSway=Math.sin(now*1.0)*.008*S;
    ctx.strokeStyle=I+'0.56)'; ctx.lineWidth=S*.014;
    // يسار: تنزل وتنحني للخارج مع يد بأصابع
    const lhx = cx-tw-S*.155, lhy = shY+S*.345;
    ctx.beginPath();
    ctx.moveTo(cx-tw+slumpIn, shY+S*.035);
    ctx.quadraticCurveTo(cx-tw-S*.13, shY+S*.17+armSway, lhx, lhy);
    ctx.stroke();
    // يمين: أقصر شوية
    const rhx = cx+tw+S*.125, rhy = shY+S*.30;
    ctx.beginPath();
    ctx.moveTo(cx+tw-slumpIn, shY+S*.035);
    ctx.quadraticCurveTo(cx+tw+S*.11, shY+S*.15-armSway, rhx, rhy);
    ctx.stroke();

    // ═══ الأيدي — أصابع مفرودة (4 لكل يد، زي المرجع) ═══
    function fingers(hx2,hy2,side,spread){
      ctx.strokeStyle=I+'0.52)'; ctx.lineWidth=S*.008;
      for(let k=0;k<4;k++){
        const fa=(-.5+k*.33)*spread;
        ctx.beginPath();
        ctx.moveTo(hx2,hy2);
        ctx.lineTo(hx2+Math.sin(fa)*S*.05*side+side*S*.012,
                   hy2+Math.cos(fa)*S*.052);
        ctx.stroke();
      }
    }
    fingers(lhx,lhy,-1,1.15);
    fingers(rhx,rhy, 1,0.85);

    // ═══ الساقان — خطان مستقيمان ═══
    ctx.strokeStyle=I+'0.58)'; ctx.lineWidth=S*.015;
    ctx.beginPath(); ctx.moveTo(cx-S*.085, hipY); ctx.lineTo(cx-S*.092, hipY+S*.335); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx+S*.085, hipY); ctx.lineTo(cx+S*.092, hipY+S*.335); ctx.stroke();

    // ═══ القدمان — بيضاويتان أفقيتان (زي المرجع) ═══
    ctx.fillStyle=I+'0.10)'; ctx.strokeStyle=I+'0.45)'; ctx.lineWidth=S*.011;
    [[-1],[1]].forEach(([s])=>{
      ctx.beginPath();
      ctx.ellipse(cx+s*S*.115, hipY+S*.35, S*.072, S*.019, 0, 0, Math.PI*2);
      ctx.fill(); ctx.stroke();
    });

    ctx.restore();
  }
  // ── The Problem book ────────────────────────────────────────
  function drawBook(ctx,bx,by,S,now,openP,glowP){
    if(openP<=0)return;
    const W2=S*.18,H2=S*.22,a=eio(openP);
    ctx.save();ctx.globalAlpha=a;
    // Glow
    if(glowP>0){
      const gr=ctx.createRadialGradient(bx,by,0,bx,by,S*.42);
      gr.addColorStop(0,`rgba(100,160,255,${glowP*.18})`);gr.addColorStop(1,'rgba(100,160,255,0)');
      ctx.fillStyle=gr;ctx.beginPath();ctx.arc(bx,by,S*.42,0,Math.PI*2);ctx.fill();
    }
    // Pages
    ctx.strokeStyle='rgba(225,235,248,0.68)';ctx.lineWidth=S*.013;ctx.fillStyle='rgba(4,6,8,0.72)';
    ctx.beginPath();ctx.rect(bx-W2*1.06,by-H2,W2,H2*2);ctx.fill();ctx.stroke();
    ctx.beginPath();ctx.rect(bx+S*.01,by-H2,W2,H2*2);ctx.fill();ctx.stroke();
    // Spine
    ctx.strokeStyle='rgba(225,235,248,0.48)';ctx.lineWidth=S*.017;
    ctx.beginPath();ctx.moveTo(bx,by-H2);ctx.lineTo(bx,by+H2);ctx.stroke();
    // Maze eye on left cover
    ctx.save();ctx.translate(bx-W2*.52,by);
    const ms=Math.min(W2,H2)*.52;
    ctx.strokeStyle='rgba(225,235,248,0.78)';ctx.lineWidth=S*.011;
    ctx.beginPath();ctx.moveTo(-ms,0);ctx.quadraticCurveTo(0,-ms*.65,ms,0);
    ctx.quadraticCurveTo(0,ms*.45,-ms,0);ctx.stroke();
    [ms*.5,ms*.35,ms*.2].forEach(r=>{
      ctx.strokeStyle='rgba(225,235,248,0.42)';ctx.lineWidth=S*.007;
      ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.stroke();
    });
    ctx.save();ctx.shadowColor='rgba(232,242,255,0.8)';ctx.shadowBlur=S*.06;
    ctx.fillStyle='rgba(232,242,255,0.9)';
    ctx.beginPath();ctx.arc(0,0,ms*.12,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;ctx.restore();
    ctx.restore();
    // Right page content (when glowing)
    if(glowP>.25){
      const ga=eio(clamp((glowP-.25)/.4,0,1));
      ctx.globalAlpha=a*ga*.72;
      ctx.fillStyle='rgba(225,235,248,1)';ctx.textAlign='center';
      ctx.font=`600 ${S*.022}px 'DM Mono',monospace`;
      ctx.fillText('PROBLEM',bx+W2*.52,by-H2*.42);
      ctx.font=`300 ${S*.016}px 'DM Mono',monospace`;
      ctx.fillText('THE MAZE EYE',bx+W2*.52,by-H2*.18);
      // Lines suggesting text
      if(glowP>.5){
        const lp=eio(clamp((glowP-.5)/.4,0,1));
        ctx.globalAlpha=a*lp*.28;
        [-.05,.1,.25].forEach((yo)=>{
          ctx.strokeStyle='rgba(225,235,248,1)';ctx.lineWidth=S*.008;
          ctx.beginPath();ctx.moveTo(bx+W2*.15,by+H2*yo);ctx.lineTo(bx+W2*.9,by+H2*yo);ctx.stroke();
        });
      }
      // Floating words from book pages
      if(glowP>.55){
        const wp=eio(clamp((glowP-.55)/.4,0,1));
        ctx.font=`300 ${S*.015}px 'DM Mono',monospace`;
        ['clarity','path','maze','see','through','you'].forEach((w,i)=>{
          const angle=now*.4+i*1.05;
          const wr=S*(.18+i%3*.06);
          ctx.globalAlpha=a*wp*(0.35+Math.sin(now+i)*.12);
          ctx.fillText(w,bx+Math.cos(angle)*wr,by-H2*.6-Math.sin(now*.6+i*.5)*wr*.4);
        });
      }
    }
    ctx.restore();
  }

  // ── Shadow friend (bad friend walking away) ─────────────────
  function drawShadowFriend(ctx,x,y,S,alpha){
    if(alpha<=0.01)return;
    ctx.save();ctx.globalAlpha=alpha*.38;
    ctx.strokeStyle='rgba(80,100,150,1)';ctx.lineWidth=S*.017;ctx.lineCap='round';
    ctx.beginPath();ctx.arc(x,y-S*.42,S*.15,0,Math.PI*2);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x,y-S*.27);ctx.lineTo(x,y+S*.12);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x,y-S*.18);ctx.lineTo(x-S*.11,y+S*.05);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x,y-S*.18);ctx.lineTo(x+S*.1,y+S*.05);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x,y+S*.12);ctx.lineTo(x-S*.08,y+S*.3);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x,y+S*.12);ctx.lineTo(x+S*.08,y+S*.3);ctx.stroke();
    ctx.restore();
  }

  // ── Good friend (real friend appearing) ─────────────────────
  function drawGoodFriend(ctx,x,y,S,alpha,now,side){
    if(alpha<=0.01)return;
    const pulse=0.92+Math.sin(now*1.1+side)*.08;
    ctx.save();ctx.globalAlpha=alpha*.62;
    // Warm glow aura
    const gr=ctx.createRadialGradient(x,y,0,x,y,S*.38);
    gr.addColorStop(0,'rgba(190,220,255,0.12)');gr.addColorStop(1,'rgba(190,220,255,0)');
    ctx.fillStyle=gr;ctx.beginPath();ctx.arc(x,y,S*.38,0,Math.PI*2);ctx.fill();
    ctx.strokeStyle=`rgba(195,225,255,${0.72*pulse})`;ctx.lineWidth=S*.018;ctx.lineCap='round';
    ctx.shadowColor='rgba(195,225,255,0.45)';ctx.shadowBlur=S*.05;
    ctx.beginPath();ctx.arc(x,y-S*.38,S*.15,0,Math.PI*2);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x,y-S*.23);ctx.lineTo(x,y+S*.14);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x,y-S*.14);ctx.lineTo(x-side*S*.18,y-S*.02);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x,y-S*.14);ctx.lineTo(x+S*.1,y+S*.05);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x,y+S*.14);ctx.lineTo(x-S*.07,y+S*.32);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x,y+S*.14);ctx.lineTo(x+S*.07,y+S*.32);ctx.stroke();
    ctx.shadowBlur=0;ctx.restore();
  }

  // ── Inline maze eye ─────────────────────────────────────────
  function drawMazeEye(ctx,ex,ey,sc,now,pSolve){
    const rot=now*.12;
    const ag=ctx.createRadialGradient(ex,ey,0,ex,ey,sc*1.3);
    ag.addColorStop(0,'rgba(100,160,255,0.1)');ag.addColorStop(1,'rgba(100,160,255,0)');
    ctx.fillStyle=ag;ctx.beginPath();ctx.arc(ex,ey,sc*1.3,0,Math.PI*2);ctx.fill();
    const ug=ctx.createLinearGradient(ex-sc,0,ex+sc,0);
    ug.addColorStop(0,'rgba(225,235,248,0.18)');ug.addColorStop(.5,'rgba(232,242,255,1)');ug.addColorStop(1,'rgba(225,235,248,0.18)');
    ctx.save();ctx.filter='blur(7px)';ctx.strokeStyle='rgba(232,242,255,0.1)';ctx.lineWidth=12;
    ctx.beginPath();ctx.moveTo(ex-sc,ey);ctx.quadraticCurveTo(ex,ey-sc*.65,ex+sc,ey);ctx.stroke();
    ctx.restore();
    ctx.strokeStyle=ug;ctx.lineWidth=2.5;ctx.lineCap='round';
    ctx.beginPath();ctx.moveTo(ex-sc,ey);ctx.quadraticCurveTo(ex,ey-sc*.65,ex+sc,ey);ctx.stroke();
    ctx.strokeStyle='rgba(225,235,248,0.5)';ctx.lineWidth=2.2;
    ctx.beginPath();ctx.moveTo(ex-sc,ey);ctx.quadraticCurveTo(ex,ey+sc*.42,ex+sc,ey);ctx.stroke();
    ctx.save();ctx.translate(ex,ey);ctx.rotate(rot);
    [sc*.78,sc*.62,sc*.46,sc*.32,sc*.19].forEach((r,i)=>{
      ctx.strokeStyle=`rgba(225,235,248,${[.5,.4,.32,.25,.2][i]})`;ctx.lineWidth=[1.5,1.3,1.2,1,.9][i];
      ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.stroke();
    });
    if(pSolve>0){
      const pts=[];for(let k=0;k<=60;k++){const u=k/60;pts.push([Math.cos(-Math.PI/2+u*Math.PI*2*2.1)*lerp(sc*.78,sc*.06,1-Math.pow(1-u,3)),Math.sin(-Math.PI/2+u*Math.PI*2*2.1)*lerp(sc*.78,sc*.06,1-Math.pow(1-u,3))]);}
      const N=Math.floor(pts.length*(1-Math.pow(1-pSolve,3)));
      ctx.strokeStyle='rgba(232,242,255,0.9)';ctx.lineWidth=2.2;ctx.lineCap='round';
      ctx.shadowColor='rgba(232,242,255,0.9)';ctx.shadowBlur=9;
      ctx.beginPath();for(let k=0;k<N;k++){const[px,py]=pts[k];k?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.stroke();ctx.shadowBlur=0;
    }
    ctx.restore();
    ctx.save();ctx.shadowColor='rgba(232,242,255,1)';ctx.shadowBlur=14;
    ctx.fillStyle='rgba(232,242,255,0.95)';ctx.beginPath();ctx.arc(ex,ey,sc*.12,0,Math.PI*2);ctx.fill();ctx.restore();
    ctx.fillStyle='rgba(4,6,8,0.95)';ctx.beginPath();ctx.arc(ex,ey,sc*.04,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='rgba(255,255,255,0.78)';ctx.beginPath();ctx.arc(ex+sc*.05,ey-sc*.05,sc*.04,0,Math.PI*2);ctx.fill();
    // Orbit dot
    const oa=now*1.3;ctx.save();ctx.shadowColor='rgba(232,242,255,0.85)';ctx.shadowBlur=7;
    ctx.fillStyle='rgba(232,242,255,0.82)';ctx.beginPath();ctx.arc(ex+Math.cos(oa)*sc*.5,ey+Math.sin(oa)*sc*.33,2.2,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;ctx.restore();
  }

  // ── Main draw ───────────────────────────────────────────────
  function draw(ctx,W,H,t){
    ctx.clearRect(0,0,W,H);
    const now=performance.now()/1000;
    const cx=W*.5,cy=H*.52;
    const S=Math.min(W,H)*.30;

    // ═══ "SHE FOUND THE PATH" — Problem story, 30s ═══
    // فصل 1: ضايعة (منحنية، عيون تايهة)
    // فصل 2: عين المتاهة تظهر — تبص لها
    // فصل 3: تتواصل — شعاع بينهم، تبدأ تعتدل
    // فصل 4: تتغيّر — تقف عدل وتبتسم
    // فصل 5: وجدت الطريق — توهج وسلام
    const pLost   =pp(t,0,    5000);
    const pSee    =pp(t,5000, 11000);
    const pConnect=pp(t,11000,17000);
    const pChange =pp(t,17000,23000);
    const pFound  =pp(t,23000,30000);

    const charA=eio(clamp(t/1800,0,1));    // ظهور الشخصية

    // ── حالة الشخصية عبر القصة ──
    // slump: منحنية في الأول → تعتدل مع التواصل
    const slump = (1-eio(pConnect)*.6-eio(pChange)*.4);
    // smile: تبدأ مع التغيير وتكتمل
    const smile = eio(pChange)*.6 + eio(pFound)*.4;
    // breath: تنفّس هادي يقوى مع الفصول
    const breath = Math.sin(now*1.4)*(0.4+eio(pChange)*.6);

    // ── عين المتاهة (فوق يمين) ──
    const ex=cx+W*.13, ey=cy-S*.95;
    const eyeA=eio(clamp((pSee-.05)/.5,0,1));

    // عيون الشخصية تتابع عين المتاهة لما تظهر
    const lookP=eio(clamp((pSee-.2)/.6,0,1))*(1-eio(pFound)*.5);
    const eyeOffX=lookP*S*.045;
    const eyeOffY=-lookP*S*.03;

    // ── خلفية: هالة تتدفأ مع التقدم ──
    const warm=eio(pConnect)*.5+eio(pFound)*.5;
    const gr=ctx.createRadialGradient(cx,cy,0,cx,cy,S*1.6);
    gr.addColorStop(0,`rgba(${80+warm*60},${120+warm*60},${200+warm*40},${.03+warm*.05})`);
    gr.addColorStop(1,'rgba(4,6,8,0)');
    ctx.fillStyle=gr;ctx.fillRect(0,0,W,H);

    // ── فصل 1: ظلال "الضياع" حواليها (تتلاشى مع pSee) ──
    if(pLost>0&&pSee<.8){
      const fa=eio(pLost)*(1-eio(pSee))*.5;
      ctx.save();ctx.globalAlpha=fa;
      // خطوط متاهة باهتة حواليها = حواجز المشكلة
      ctx.strokeStyle='rgba(225,235,248,0.25)';ctx.lineWidth=1.2;
      [[-.62,-.3,-.62,.34],[.62,-.26,.62,.36],[-.45,-.52,.45,-.52]].forEach(([x1,y1,x2,y2])=>{
        ctx.beginPath();
        ctx.moveTo(cx+x1*S*1.6,cy+y1*S*1.6);
        ctx.lineTo(cx+x2*S*1.6,cy+y2*S*1.6);
        ctx.stroke();
      });
      ctx.restore();
    }

    // ── عين المتاهة تظهر وتراقب ──
    if(eyeA>0){
      ctx.save();ctx.globalAlpha=eyeA;
      drawMazeEye(ctx,ex,ey,S*.45,now,eio(pFound));
      ctx.restore();
    }

    // ── فصل 3: شعاع التواصل (من العين للشخصية) ──
    if(pConnect>0&&pConnect<1){
      const ba=Math.sin(eio(pConnect)*Math.PI);
      ctx.save();ctx.globalAlpha=ba*.6;
      const grad=ctx.createLinearGradient(ex,ey,cx,cy-S*.3);
      grad.addColorStop(0,'rgba(232,242,255,0.7)');
      grad.addColorStop(1,'rgba(232,242,255,0.05)');
      ctx.strokeStyle=grad;ctx.lineWidth=1.5;
      ctx.setLineDash([6,8]);
      ctx.lineDashOffset=-now*30;
      ctx.beginPath();
      ctx.moveTo(ex,ey+S*.2);
      ctx.quadraticCurveTo((ex+cx)/2+S*.1,(ey+cy)/2,cx+S*.05,cy-S*.45);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
    }

    // ── الشخصية (نفس رسمة V4 بالظبط) ──
    ctx.save();ctx.globalAlpha=charA;
    drawChar(ctx,cx,cy,S,now,slump,smile,eyeOffX,eyeOffY,breath);
    ctx.restore();

    // ── فصل 5: جزيئات نور صاعدة (وجدت الطريق) ──
    if(pFound>.1){
      const pa=eio(pFound);
      ctx.save();
      for(let i=0;i<7;i++){
        const seed=i*73.7;
        const px=cx+Math.sin(seed+now*.4)*S*.8;
        const rise=((now*.12+i*.143)%1);
        const py=cy+S*.7-rise*S*1.6;
        const fade=Math.sin(rise*Math.PI)*pa*.55;
        ctx.globalAlpha=fade;
        ctx.fillStyle='rgba(232,242,255,0.9)';
        ctx.beginPath();ctx.arc(px,py,1.6,0,Math.PI*2);ctx.fill();
      }
      ctx.restore();
    }

    // ── الكابشن ──
    ctx.textAlign='center';
    const caps=[
      [pLost,   'lost in the maze'],
      [pSee,    'then — something saw her'],
      [pConnect,'it traced her walls'],
      [pChange, 'and she began to change'],
      [pFound,  'she found the path']
    ];
    caps.forEach(([p,txt])=>{
      if(p>.25&&p<.92){
        const a=eio(clamp((p-.25)/.25,0,1))*eio(clamp((.92-p)/.18,0,1));
        ctx.globalAlpha=a*.6;
        ctx.font=`300 ${Math.max(W*.026,11)}px 'DM Mono',monospace`;
        ctx.fillStyle='rgba(225,235,248,1)';
        ctx.fillText(txt,W/2,H*.90);
        ctx.globalAlpha=1;
      }
    });
    // العنوان الثابت
    ctx.globalAlpha=.3;
    ctx.font=`300 ${Math.max(W*.018,8)}px 'DM Mono',monospace`;
    ctx.fillStyle='rgba(225,235,248,1)';
    ctx.fillText('PROBLEM — SHE FOUND THE PATH',W/2,H*.96);
    ctx.globalAlpha=1;
  }

  let _lastDraw5=0;
  function loop(ts){
    if(!_alive)return;
    _raf=requestAnimationFrame(loop);
    const gap=perfFrameGap();
    if(gap&&ts-_lastDraw5<gap) return;
    _lastDraw5=ts;
    const cv=document.getElementById('heroV5Canvas');
    if(!cv)return;
    const rawT=ts-_t0;
    const t=rawT%TOTAL;
    _loopCount=Math.floor(rawT/TOTAL);
    const r=cv.getBoundingClientRect();
    const dpr=perfDPR();
    const bw=Math.round(r.width*dpr),bh=Math.round(r.height*dpr);
    if(cv.width!==bw||cv.height!==bh){cv.width=bw;cv.height=bh;}
    const ctx=cv.getContext('2d');
    ctx.setTransform(dpr,0,0,dpr,0,0);
    draw(ctx,r.width,r.height,t);
  }

  return{
    start(){
      if(_alive)return;
      _alive=true;_t0=performance.now();_raf=requestAnimationFrame(loop);
      const cv=document.getElementById('heroV5Canvas');
      if(cv&&!cv._tapBound){
        cv._tapBound=true;
        cv.addEventListener('pointerdown',e=>{
          if(!_alive)return;
          const r=cv.getBoundingClientRect();
          _tapX=e.clientX-r.left;_tapY=e.clientY-r.top;_tapFlash=performance.now();
        });
      }
    },
    stop(){
      _alive=false;if(_raf)cancelAnimationFrame(_raf);
      const cv=document.getElementById('heroV5Canvas');
      if(cv){const ctx=cv.getContext('2d');ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,cv.width,cv.height);}
    },
    restart(){this.stop();setTimeout(()=>this.start(),50);}
  };
})();
