const V3 = (function(){
  let _raf=null, _alive=false, _prog=0, _t=0, _last=0;

  // ── helpers ───────────────────────────────────────────────
  function rgba(name,a){
    // V3 always renders inside the dark eye-island. In light mode the root
    // CSS vars are dark ink (15,22,40) which would be invisible on the island —
    // so force the luminous dark-mode palette here regardless of page theme.
    if(document.documentElement.getAttribute('data-theme')==='light'){
      return name==='cyan'?`rgba(232,242,255,${a})`:`rgba(225,235,248,${a})`;
    }
    const v=getComputedStyle(document.documentElement).getPropertyValue('--'+name).trim();
    return v?`rgba(${v},${a})`:(name==='cyan'?`rgba(232,242,255,${a})`:`rgba(225,235,248,${a})`);
  }
  function glow(ctx,col,b){ctx.shadowColor=col;ctx.shadowBlur=b;}
  function noGlow(ctx){ctx.shadowBlur=0;}
  function easeInOut(t){return t<0.5?2*t*t:1-2*(1-t)*(1-t);}

  // ── DRAW ──────────────────────────────────────────────────
  function draw(cv,prog,t){
    const W=cv.width,H=cv.height;
    const ctx=cv.getContext('2d');
    ctx.clearRect(0,0,W,H);

    const sc=Math.min(W,H)/750;
    const cx=W*0.40, cy=H*0.50;
    const floatY=Math.sin(t*0.75)*7*Math.min(prog*4,1);

    ctx.save();
    ctx.translate(cx, cy+floatY);
    ctx.scale(sc,sc);

    const ice  = rgba('ice',0.92);
    const ice6 = rgba('ice',0.6);
    const ice3 = rgba('ice',0.32);
    const cyan = rgba('cyan',1);
    const cyanD= rgba('cyan',0.3);

    // ══════════════════════════════════════════════════
    //  1. FACE PROFILE — smooth bezier, reveals top→bottom
    // ══════════════════════════════════════════════════
    const fp = Math.min(prog/0.5, 1);  // 0→1 during first 50% of draw
    if(fp>0){
      // Clip: top portion expands downward
      ctx.save();
      ctx.beginPath();
      ctx.rect(-220, -260, 680, 460*fp);
      ctx.clip();

      ctx.beginPath();
      // Smooth face profile using bezier curves:
      // crown → forehead → brow → cheek → nose → lips → chin → neck
      ctx.moveTo(  0, -220);                                   // crown
      ctx.bezierCurveTo(-22,-228,  -58,-215,  -76,-182);      // forehead slopes left
      ctx.bezierCurveTo(-90,-158,  -95,-130,  -94, -96);      // brow ridge → cheek
      ctx.bezierCurveTo(-93, -62,  -95, -30,  -93,  -4);      // nose bridge (slight indent)
      ctx.bezierCurveTo(-97,  10,  -92,  22,  -84,  28);      // nose tip (protrudes)
      ctx.bezierCurveTo(-78,  33,  -83,  46,  -80,  58);      // philtrum → upper lip
      ctx.bezierCurveTo(-77,  70,  -74,  80,  -62,  92);      // lower lip → chin
      ctx.bezierCurveTo(-50, 104,  -40, 118,  -44, 142);      // jaw curves back
      ctx.bezierCurveTo(-48, 162,  -46, 175,  -44, 192);      // neck

      ctx.strokeStyle = ice;
      ctx.lineWidth   = 2.8;
      ctx.lineCap     = 'round';
      ctx.lineJoin    = 'round';
      glow(ctx, cyanD, 9);
      ctx.stroke();
      noGlow(ctx);
      ctx.restore();
    }

    // ══════════════════════════════════════════════════
    //  2. SKULL RIGHT — clean then dissolves (dashed)
    // ══════════════════════════════════════════════════
    const sp = Math.min((prog-0.15)/0.35, 1);
    if(sp>0){
      ctx.save();
      ctx.beginPath();
      ctx.rect(-220,-260,680,460*sp);
      ctx.clip();

      ctx.beginPath();
      ctx.moveTo(  0, -220);                                   // same crown
      ctx.bezierCurveTo( 30,-228,   65,-215,   82,-182);      // right forehead
      ctx.bezierCurveTo( 96,-155,  100,-118,   98, -80);      // temporal → parietal
      ctx.bezierCurveTo( 96, -42,   90,  -4,   80,  28);      // occipital
      ctx.bezierCurveTo( 70,  52,   60,  68,   54,  82);      // dissolves here

      ctx.strokeStyle = ice6;
      ctx.lineWidth   = 2.2;
      ctx.lineCap     = 'round';
      ctx.setLineDash([5,4]);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
    }

    // ══════════════════════════════════════════════════
    //  3. EYE — left side, where profile has eye socket
    // ══════════════════════════════════════════════════
    const ep = Math.min((prog-0.32)/0.18, 1);
    if(ep>0){
      ctx.save();
      ctx.globalAlpha = ep;
      ctx.translate(-84, -88);  // eye position on the face profile
      // Blink
      const blink = (Math.sin(t*0.6)>0.92) ? 0.07 : 1;
      ctx.scale(1, blink);

      // Almond shape
      ctx.beginPath();
      ctx.moveTo(-16, 0);
      ctx.quadraticCurveTo( 0,-11,  16,  0);
      ctx.quadraticCurveTo( 0, 11, -16,  0);
      ctx.strokeStyle = rgba('ice',0.85);
      ctx.lineWidth   = 1.8;
      ctx.lineCap     = 'round';
      ctx.stroke();

      // Iris
      ctx.beginPath();
      ctx.arc(0,0,6.5,0,Math.PI*2);
      ctx.strokeStyle = rgba('ice',0.38);
      ctx.lineWidth   = 1;
      ctx.stroke();

      // Pupil — cyan + darts
      const dx = Math.sin(Math.floor(t*1.1)*2.6)*3.5;
      const dy = Math.cos(Math.floor(t*0.9)*2.2)*1.8;
      ctx.beginPath();
      ctx.arc(dx,dy,3.8,0,Math.PI*2);
      ctx.fillStyle = cyan;
      glow(ctx,cyan,10);
      ctx.fill();
      noGlow(ctx);
      ctx.restore();
    }

    // ══════════════════════════════════════════════════
    //  4. MAZE — right hemisphere (the tangled problem)
    // ══════════════════════════════════════════════════
    const mp = Math.min((prog-0.35)/0.25, 1);
    if(mp>0){
      ctx.save();
      ctx.translate(48, -18);
      ctx.rotate(t*0.032);
      ctx.globalAlpha = mp*0.9;
      ctx.strokeStyle = ice;
      ctx.lineWidth   = 1.8;
      ctx.lineCap     = 'round';
      ctx.lineJoin    = 'round';
      glow(ctx, cyanD, 5);

      ctx.beginPath();
      ctx.moveTo( 12,-30);
      ctx.bezierCurveTo( 32,-20,  30,  2,  14, 8);
      ctx.bezierCurveTo( -2, 14, -16,  4, -12,-12);
      ctx.bezierCurveTo( -8,-28,   8,-34,  22,-24);
      ctx.bezierCurveTo( 36,-14,  38, 10,  20, 20);
      ctx.bezierCurveTo(  2, 30, -18, 26, -22,  8);
      ctx.bezierCurveTo(-26,-10, -16,-32,   2,-38);
      ctx.stroke();
      noGlow(ctx);
      ctx.restore();
    }

    // ══════════════════════════════════════════════════
    //  5. PATH — emerges from chaos, goes right
    // ══════════════════════════════════════════════════
    const pp = Math.min((prog-0.58)/0.28, 1);
    if(pp>0){
      const glowA = 0.28+0.14*Math.sin(t*1.1);
      // Glow layer
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(92, 18);
      ctx.bezierCurveTo(160,-10, 240,-26, 330,-34);
      ctx.bezierCurveTo(390,-40, 430,-36, 470,-40);
      ctx.strokeStyle = rgba('cyan', glowA*pp);
      ctx.lineWidth   = 10;
      ctx.lineCap     = 'round';
      glow(ctx,cyan,16);
      ctx.stroke();
      noGlow(ctx);
      // Main line — reveal left→right with clip
      ctx.beginPath();
      ctx.rect(88,-80,400*pp,100);
      ctx.clip();
      ctx.beginPath();
      ctx.moveTo(92, 18);
      ctx.bezierCurveTo(160,-10, 240,-26, 330,-34);
      ctx.bezierCurveTo(390,-40, 430,-36, 470,-40);
      ctx.strokeStyle = ice;
      ctx.lineWidth   = 2.4;
      ctx.lineCap     = 'round';
      ctx.stroke();
      ctx.restore();

      // Tip dot
      if(pp>0.7){
        const ta=Math.min((pp-0.7)/0.3,1);
        ctx.beginPath();
        ctx.arc(92+380*pp, 18+(-58)*pp, 5, 0, Math.PI*2);
        ctx.fillStyle = rgba('ice',ta);
        glow(ctx,cyan,12);
        ctx.fill();
        noGlow(ctx);
      }
    }

    // ══════════════════════════════════════════════════
    //  6. AWARENESS DOT — floats above, orbits, glows
    // ══════════════════════════════════════════════════
    const dp = Math.min((prog-0.76)/0.24, 1);
    if(dp>0){
      const angle = t*0.7;
      const ox=Math.cos(angle)*14, oy=Math.sin(angle)*9;
      const dx=38+ox, dy=-258+oy;

      // Halo
      const g=ctx.createRadialGradient(dx,dy,0,dx,dy,40);
      g.addColorStop(0,   rgba('cyan',0.32*dp));
      g.addColorStop(0.5, rgba('cyan',0.12*dp));
      g.addColorStop(1,   rgba('cyan',0));
      ctx.beginPath(); ctx.arc(dx,dy,40,0,Math.PI*2);
      ctx.fillStyle=g; ctx.fill();

      // Core — color shifts for hope
      const h=(Math.sin(t*0.55)+1)*0.5;
      const cr=Math.round(232+h*18), cg=Math.round(242+h*8);
      ctx.beginPath(); ctx.arc(dx,dy,20*dp,0,Math.PI*2);
      ctx.fillStyle=`rgba(${cr},${cg},255,${0.94*dp})`;
      glow(ctx,cyan,18); ctx.fill(); noGlow(ctx);
    }

    ctx.restore();

    // Label
    if(prog>0.92){
      ctx.globalAlpha=(prog-0.92)/0.08*0.35;
      ctx.fillStyle=rgba('id',1)||'rgba(225,235,248,0.35)';
      ctx.font=`11px 'DM Mono',monospace`;
      ctx.textAlign='center';
      ctx.fillText('TAP TO REDRAW', W*0.40, H-42);
      ctx.globalAlpha=1;
    }
  }

  // ── loop ─────────────────────────────────────────────────
  let _lastDraw=0;
  function loop(ts){
    if(!_alive) return;
    _raf=requestAnimationFrame(loop);
    // FPS throttle حسب قدرة الجهاز
    const gap=perfFrameGap();
    if(gap&&ts-_lastDraw<gap) return;
    _lastDraw=ts;
    const dt=Math.min((ts-_last)/1000,0.05); _last=ts;
    if(_prog<1) _prog=Math.min(_prog+dt*0.26,1);
    else _t+=dt;
    const cv=document.getElementById('heroV3Canvas');
    if(!cv) return;
    // Buffer = حجم العرض الفعلي × DPR المناسب للجهاز (مش 900×750 ثابت)
    const r=cv.getBoundingClientRect();
    if(r.width>0){
      const dpr=perfDPR();
      const bw=Math.round(r.width*dpr), bh=Math.round(r.height*dpr);
      if(cv.width!==bw||cv.height!==bh){cv.width=bw;cv.height=bh;}
    }
    draw(cv,easeInOut(_prog),_t);
  }

  return{
    start(){
      if(_alive)return; _alive=true; _prog=0; _t=0;
      _last=performance.now(); _raf=requestAnimationFrame(loop);
    },
    stop(){
      _alive=false;
      if(_raf){cancelAnimationFrame(_raf);_raf=null;}
      const cv=document.getElementById('heroV3Canvas');
      if(cv) cv.getContext('2d').clearRect(0,0,cv.width,cv.height);
    },
    restart(){
      this.stop(); _alive=true; _prog=0; _t=0;
      _last=performance.now(); _raf=requestAnimationFrame(loop);
      try{navigator.vibrate&&navigator.vibrate(8);}catch(e){}
    }
  };
})();
