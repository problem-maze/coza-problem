window.SeekerCine = (function(){
  'use strict';

  var LOOP = 28000;
  var raf = 0, t0 = 0, alive = false, lastBeat = -1;

  // ── colors ──
  var COLD = [196,224,255];   // cold blue-white (in the dark/fog)
  var WARM = [255,238,206];   // warm light (at clarity)
  function mix(a,b,t){ return [a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t, a[2]+(b[2]-a[2])*t]; }
  function rgba(c,a){ return 'rgba('+(c[0]|0)+','+(c[1]|0)+','+(c[2]|0)+','+a+')'; }

  // ── easing ──
  function clamp01(x){ return x<0?0:(x>1?1:x); }
  function easeInOut(t){ return t<0.5?2*t*t:1-Math.pow(-2*t+2,2)/2; }
  function easeOut(t){ return 1-Math.pow(1-t,3); }
  function ramp(p,a,b){ return clamp01((p-a)/(b-a)); }
  function hump(p,a,b){ if(p<a||p>b) return 0; var x=(p-a)/(b-a); return Math.sin(x*Math.PI); }

  // ── the goal (the light) position in scene space ──
  var GOAL = {x:78, y:-66};

  // ════════════════════════════════════════════════════════════
  //  THE FIGURE — forward kinematics. Returns SVG string.
  //  Local origin = pelvis. Caller translates/scales/places it.
  // ════════════════════════════════════════════════════════════
  var Fig = (function(){
    var NECK_Y=-30, PELVIS_Y=6, HEAD_R=7.5;
    var THIGH=16, SHIN=17, UARM=12, FARM=11;
    var SHO_Y=-22, HIP_DX=4.5, SHO_DX=5.5;

    function pt(ang,len,x0,y0){ return [x0+Math.sin(ang)*len, y0+Math.cos(ang)*len]; }

    // o: phase, walkAmt, headTilt(+down/-up), reach(0..1), lean(rad), glow(0..1), col[]
    function build(o){
      o=o||{};
      var phase=o.phase||0, walk=(o.walkAmt!=null?o.walkAmt:0);
      var headTilt=o.headTilt||0, reach=o.reach||0, lean=o.lean||0;
      var glow=(o.glow!=null?o.glow:0.85);
      var col=o.col||COLD;
      var sw=function(a){ return rgba(col,a); };

      var twoPi=2*Math.PI;
      var swing=0.6*walk;
      var aL=Math.sin(phase*twoPi)*swing;
      var aR=Math.sin(phase*twoPi+Math.PI)*swing;
      var kneeL=Math.max(0,Math.sin(phase*twoPi-0.6))*1.0*walk;
      var kneeR=Math.max(0,Math.sin(phase*twoPi+Math.PI-0.6))*1.0*walk;
      var armL=-aR*0.95;                 // arms antiphase to legs, a bit wider
      var armR=-aL*0.95;
      var elbow=0.55*walk;
      var bob=-Math.abs(Math.sin(phase*twoPi))*1.7*walk;

      var oy=bob;
      var leanDx=Math.sin(lean)*Math.abs(NECK_Y);

      var pelvisY=oy+PELVIS_Y;
      var neckX=leanDx, neckY=oy+NECK_Y;
      var shoY=oy+SHO_Y;

      function Ln(x1,y1,x2,y2,w,a){
        return '<line x1="'+x1.toFixed(1)+'" y1="'+y1.toFixed(1)+'" x2="'+x2.toFixed(1)+'" y2="'+y2.toFixed(1)+
               '" stroke="'+sw(a)+'" stroke-width="'+w+'" stroke-linecap="round"/>';
      }
      var s='';

      // legs
      var L1=pt(aL,THIGH,-HIP_DX,pelvisY),       L2=pt(aL+kneeL,SHIN,L1[0],L1[1]);
      var R1=pt(aR,THIGH, HIP_DX,pelvisY),       R2=pt(aR+kneeR,SHIN,R1[0],R1[1]);
      s+=Ln(-HIP_DX,pelvisY,L1[0],L1[1],1.9,glow*0.92);
      s+=Ln(L1[0],L1[1],L2[0],L2[1],1.9,glow*0.92);
      s+=Ln( HIP_DX,pelvisY,R1[0],R1[1],1.9,glow*0.95);
      s+=Ln(R1[0],R1[1],R2[0],R2[1],1.9,glow*0.95);
      // torso
      s+=Ln(0,pelvisY,neckX,neckY,2.0,glow);
      // arms
      var shoLx=neckX-SHO_DX, shoRx=neckX+SHO_DX;
      var AL1=pt(armL,UARM,shoLx,shoY), AL2=pt(armL+elbow,FARM,AL1[0],AL1[1]);
      s+=Ln(shoLx,shoY,AL1[0],AL1[1],1.6,glow*0.82);
      s+=Ln(AL1[0],AL1[1],AL2[0],AL2[1],1.6,glow*0.82);
      var ra,rb;
      if(reach>0){ ra=armR*(1-reach)+(-1.2)*reach; rb=elbow*(1-reach)+(-0.45)*reach; }
      else { ra=armR; rb=elbow; }
      var AR1=pt(ra,UARM,shoRx,shoY), AR2=pt(ra+rb,FARM,AR1[0],AR1[1]);
      s+=Ln(shoRx,shoY,AR1[0],AR1[1],1.6,glow*0.85);
      s+=Ln(AR1[0],AR1[1],AR2[0],AR2[1],1.6,glow*0.85);
      // head
      var hx=neckX+Math.sin(headTilt)*2.5;
      var hy=neckY-HEAD_R-1+Math.abs(headTilt)*1.6;
      s+='<circle cx="'+hx.toFixed(1)+'" cy="'+hy.toFixed(1)+'" r="'+HEAD_R+'" fill="'+sw(0.05)+'" stroke="'+sw(glow)+'" stroke-width="1.8"/>';
      // soft halo (brightens with glow)
      s+='<circle cx="'+hx.toFixed(1)+'" cy="'+hy.toFixed(1)+'" r="'+(HEAD_R+4+glow*3).toFixed(1)+'" fill="none" stroke="'+sw(0.18+glow*0.25)+'" stroke-width="1"/>';
      return s;
    }
    return { build:build, NECK_Y:NECK_Y };
  })();

  // ════════════════════════════════════════════════════════════
  //  FOG PARTICLES — drifting motes, dense early, clearing at the end
  // ════════════════════════════════════════════════════════════
  var MOTES=[];
  function seedMotes(){
    MOTES=[];
    var n=22;
    for(var i=0;i<n;i++){
      MOTES.push({
        x:(Math.random()*2-1)*150,
        y:(Math.random()*2-1)*70 - 10,
        r:0.6+Math.random()*1.6,
        sp:0.15+Math.random()*0.5,           // drift speed
        ph:Math.random()*Math.PI*2,
        amp:6+Math.random()*16
      });
    }
  }
  function motesSVG(p, clear, col){
    var s='', t=p*LOOP/1000;
    for(var i=0;i<MOTES.length;i++){
      var m=MOTES[i];
      var dx=Math.sin(t*m.sp+m.ph)*m.amp;
      var dy=Math.cos(t*m.sp*0.7+m.ph)*m.amp*0.5;   // gentle vertical drift
      var op=(0.10+0.18*((Math.sin(t*0.8+m.ph)+1)/2))*(1-clear);
      s+='<circle cx="'+(m.x+dx).toFixed(1)+'" cy="'+(m.y+dy).toFixed(1)+'" r="'+m.r.toFixed(2)+
         '" fill="'+rgba(col,op.toFixed(3))+'"/>';
    }
    return s;
  }

  // ════════════════════════════════════════════════════════════
  //  THE PATH — figure walks this. We build it as an SVG cubic and
  //  also sample it analytically to place the figure's feet on it.
  //  Two segments: a wrong-turn stub (briefly explored) + the true path.
  // ════════════════════════════════════════════════════════════
  // true path control points (pelvis travels roughly along this), scene space
  var PATH = [
    {x:0,  y:44},   // start (figure base)
    {x:-30,y:20},
    {x:34, y:6},
    {x:20, y:-20},
    {x:54, y:-30},
    {x:GOAL.x, y:GOAL.y+8}
  ];
  // Catmull-Rom → point at t (0..1) over the whole polyline
  function pathPoint(t){
    var pts=PATH, n=pts.length-1;
    var f=t*n, i=Math.min(Math.floor(f),n-1), lt=f-i;
    var p0=pts[Math.max(0,i-1)], p1=pts[i], p2=pts[i+1], p3=pts[Math.min(n,i+2)];
    function cr(a,b,c,d){ var t2=lt*lt,t3=t2*lt; return 0.5*((2*b)+(-a+c)*lt+(2*a-5*b+4*c-d)*t2+(-a+3*b-3*c+d)*t3); }
    return { x:cr(p0.x,p1.x,p2.x,p3.x), y:cr(p0.y,p1.y,p2.y,p3.y) };
  }
  // build the visible path "d" up to fraction f (for the draw-on effect we use dashoffset instead)
  var PATH_D = (function(){
    var d='M '+PATH[0].x+' '+PATH[0].y;
    for(var i=0;i<=40;i++){ var pp=pathPoint(i/40); d+=' L '+pp.x.toFixed(1)+' '+pp.y.toFixed(1); }
    return d;
  })();
  // wrong-turn stub: branches off around t≈0.45 down-right, a dead end
  var WRONG_D='M 20 6 C 40 18, 58 30, 62 48';

  // ════════════════════════════════════════════════════════════
  //  SCAFFOLD — static structure; animated bits get ids
  // ════════════════════════════════════════════════════════════
  function scaffold(){
    return [
      '<g id="sc-fog">',
        '<circle id="sc-fog1" cx="0" cy="-20" r="150" fill="none" stroke="'+rgba(COLD,0.10)+'" stroke-width="1.1" stroke-dasharray="7 12"/>',
        '<circle id="sc-fog2" cx="0" cy="-20" r="118" fill="none" stroke="'+rgba(COLD,0.08)+'" stroke-width="1"   stroke-dasharray="5 10"/>',
        '<circle id="sc-fog3" cx="0" cy="-20" r="86"  fill="none" stroke="'+rgba(COLD,0.07)+'" stroke-width="0.9" stroke-dasharray="4 8"/>',
      '</g>',
      '<g id="sc-motes"></g>',

      // wrong-turn stub (faint, flickers when explored then fades)
      '<path id="sc-wrong" d="'+WRONG_D+'" fill="none" stroke="'+rgba(COLD,0.0)+'" stroke-width="1.6" stroke-linecap="round" stroke-dasharray="3 5"/>',

      // the true path (echo + bright), drawn via dashoffset
      '<path id="sc-path2" d="'+PATH_D+'" fill="none" stroke="'+rgba(COLD,0.22)+'" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="300" stroke-dashoffset="300"/>',
      '<path id="sc-path"  d="'+PATH_D+'" fill="none" stroke="'+rgba(COLD,0.85)+'" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" filter="url(#vpHGlow)" stroke-dasharray="300" stroke-dashoffset="300"/>',

      // the goal light
      '<g id="sc-goal" opacity="0">',
        '<circle id="sc-goal-core" cx="'+GOAL.x+'" cy="'+GOAL.y+'" r="3.2" fill="'+rgba(COLD,0.95)+'" filter="url(#vpHGlow)"/>',
        '<circle id="sc-goal-h1" cx="'+GOAL.x+'" cy="'+GOAL.y+'" r="9"  fill="none" stroke="'+rgba(COLD,0.5)+'" stroke-width="1.1"/>',
        '<circle id="sc-goal-h2" cx="'+GOAL.x+'" cy="'+GOAL.y+'" r="16" fill="none" stroke="'+rgba(COLD,0.2)+'" stroke-width="0.8"/>',
        '<g id="sc-rays"></g>',
      '</g>',

      // compass — the searching tool (phase 0-1), then dims
      '<g id="sc-compass">',
        '<circle cx="0" cy="-30" r="56" stroke="'+rgba(COLD,0.4)+'" stroke-width="1.1" fill="none"/>',
        '<circle cx="0" cy="-30" r="44" stroke="'+rgba(COLD,0.13)+'" stroke-width="0.8" fill="none"/>',
        '<line x1="0" y1="-86" x2="0" y2="-78" stroke="'+rgba(COLD,0.6)+'" stroke-width="1.3" stroke-linecap="round"/>',
        '<line x1="56" y1="-30" x2="48" y2="-30" stroke="'+rgba(COLD,0.35)+'" stroke-width="1" stroke-linecap="round"/>',
        '<line x1="0" y1="26" x2="0" y2="18" stroke="'+rgba(COLD,0.35)+'" stroke-width="1" stroke-linecap="round"/>',
        '<line x1="-56" y1="-30" x2="-48" y2="-30" stroke="'+rgba(COLD,0.35)+'" stroke-width="1" stroke-linecap="round"/>',
        '<g id="sc-needle" style="transform-box:fill-box;transform-origin:0px -30px">',
          '<line id="sc-needle-n" x1="0" y1="-30" x2="0" y2="-76" stroke="'+rgba(COLD,0.95)+'" stroke-width="2.2" stroke-linecap="round" filter="url(#vpHGlow)"/>',
          '<line x1="0" y1="-30" x2="0" y2="2" stroke="'+rgba(COLD,0.3)+'" stroke-width="1.5" stroke-linecap="round"/>',
          '<circle cx="0" cy="-30" r="3.2" fill="'+rgba(COLD,0.9)+'" filter="url(#vpHGlow)"/>',
        '</g>',
      '</g>',

      // ground glow under the figure (moves with the figure)
      '<ellipse id="sc-shadow" cx="0" cy="86" rx="34" ry="6" fill="'+rgba(COLD,0.0)+'"/>',

      // the figure (filled by render each frame)
      '<g id="sc-fig"></g>',

      // arrival burst (clarity)
      '<g id="sc-burst" opacity="0"></g>'
    ].join('');
  }

  // needle angle over time: wild spin → hunting → locks toward goal (~ up-right ≈ +40°)
  function needleAngle(p){
    if(p<0.14){ return Math.sin(p*44)*130 + p*300; }
    if(p<0.30){ var l=(p-0.14)/0.16, d=Math.pow(1-l,1.4); return 42 + Math.sin(l*20)*75*d; }
    return 42 + Math.sin(p*5)*1.4;
  }

  // ════════════════════════════════════════════════════════════
  //  BEATS (fractions of LOOP)
  //  0 fog/lost      0.00–0.14
  //  1 searching     0.14–0.30
  //  2 light appears 0.30–0.42
  //  3 first steps   0.42–0.55
  //  4 wrong turn    0.55–0.64  (hesitate, drift to dead-end, stop)
  //  5 recover+walk  0.64–0.82  (turn back, walk the true path)
  //  6 reach         0.82–0.90  (near light, arm reaches)
  //  7 clarity       0.90–1.00  (arrive, warmth, breath, fade)
  // ════════════════════════════════════════════════════════════
  function beatOf(p){
    if(p<0.14) return 0; if(p<0.30) return 1; if(p<0.42) return 2;
    if(p<0.55) return 3; if(p<0.64) return 4; if(p<0.82) return 5;
    if(p<0.90) return 6; return 7;
  }

  var ANN={
    en:[
      ['','LOST IN THE FOG',''],
      ['STILL','SEARCHING','FOR A SIGN'],
      ['A LIGHT','APPEARS','IN THE DARK'],
      ['THE FIRST','STEPS','ARE HARDEST'],
      ['A WRONG','TURN','— NOT THE WAY'],
      ['FINDING','THE PATH','AGAIN'],
      ['ALMOST','THERE','— REACH'],
      ['YOU FOUND','THE WAY','OUT']
    ],
    ar:[
      ['','تايه في الضباب',''],
      ['لسه','بيدوّر','على إشارة'],
      ['نور','بان','في الظلام'],
      ['أول','خطوة','هي الأصعب'],
      ['طريق','غلط','— مش هنا'],
      ['بيلاقي','الطريق','تاني'],
      ['قرّب','يوصل','— مدّ إيدك'],
      ['لقيت','طريق الخروج','']
    ]
  };
  function lang(){ try{ return (typeof CURRENT_LANG!=='undefined'&&CURRENT_LANG==='ar')?'ar':'en'; }catch(e){ return 'en'; } }

  // ════════════════════════════════════════════════════════════
  //  RENDER one frame at p∈[0,1]
  // ════════════════════════════════════════════════════════════
  function render(p){
    var beat=beatOf(p);
    var warmth=easeOut(ramp(p,0.86,1.0));          // 0 cold → 1 warm at clarity
    var col=mix(COLD,WARM,warmth);

    // ── fog rings ──
    var fogClear=ramp(p,0.86,0.99);
    var fog=document.getElementById('sc-fog');
    if(fog){
      fog.style.opacity=(0.5*(1-fogClear)+0.08).toFixed(3);
      fog.style.transformBox='fill-box'; fog.style.transformOrigin='0px -20px';
      fog.style.transform='rotate('+(p*36).toFixed(2)+'deg)';
    }
    // ── motes ──
    var motes=document.getElementById('sc-motes');
    if(motes) motes.innerHTML=motesSVG(p,fogClear,col);

    // ── compass: bright while searching, dims as we walk away ──
    var comp=document.getElementById('sc-compass');
    if(comp){ comp.style.opacity=(1-ramp(p,0.44,0.66)*0.8).toFixed(3); }
    var nd=document.getElementById('sc-needle');
    if(nd) nd.style.transform='rotate('+needleAngle(p).toFixed(2)+'deg)';
    var ndN=document.getElementById('sc-needle-n');
    if(ndN) ndN.setAttribute('stroke-width',(2.2+hump(p,0.28,0.36)*1.6).toFixed(2));

    // ── goal light ──
    var goal=document.getElementById('sc-goal');
    if(goal){
      var gIn=ramp(p,0.30,0.42), gBloom=hump(p,0.88,1.0);
      goal.style.opacity=clamp01(gIn).toFixed(3);
      var gc=document.getElementById('sc-goal-core');
      var h1=document.getElementById('sc-goal-h1'), h2=document.getElementById('sc-goal-h2');
      if(gc){ gc.setAttribute('r',(3.2+gBloom*4).toFixed(2)); gc.setAttribute('fill',rgba(col,0.95)); }
      if(h1){ h1.setAttribute('r',(9+gBloom*14).toFixed(1)); h1.setAttribute('stroke',rgba(col,0.5)); }
      if(h2){ h2.setAttribute('r',(16+gBloom*26).toFixed(1)); h2.setAttribute('stroke',rgba(col,0.2)); }
      // rays bloom at clarity
      var rays=document.getElementById('sc-rays');
      if(rays){
        if(gBloom>0.02){
          var rs='';
          for(var i=0;i<12;i++){
            var a=i/12*Math.PI*2, len=10+gBloom*22;
            rs+='<line x1="'+(GOAL.x+Math.cos(a)*6).toFixed(1)+'" y1="'+(GOAL.y+Math.sin(a)*6).toFixed(1)+
                '" x2="'+(GOAL.x+Math.cos(a)*len).toFixed(1)+'" y2="'+(GOAL.y+Math.sin(a)*len).toFixed(1)+
                '" stroke="'+rgba(col,(0.35*gBloom).toFixed(3))+'" stroke-width="1" stroke-linecap="round"/>';
          }
          rays.innerHTML=rs;
        } else rays.innerHTML='';
      }
    }

    // ── path draw-on: true path appears as the figure commits (beat 3 onward),
    //    fully drawn by the time we reach. Wrong-turn stub flickers in beat 4. ──
    var draw=easeInOut(ramp(p,0.42,0.80));
    var off=(300*(1-draw)).toFixed(1);
    var pa=document.getElementById('sc-path'), pa2=document.getElementById('sc-path2');
    if(pa) pa.setAttribute('stroke-dashoffset',off);
    if(pa2) pa2.setAttribute('stroke-dashoffset',off);
    if(pa){ pa.setAttribute('stroke',rgba(col,(0.85).toFixed(2))); }
    // wrong-turn stub: visible only during the hesitation (beat 4), then fades
    var wrong=document.getElementById('sc-wrong');
    if(wrong){
      var wOp=hump(p,0.55,0.66)*0.5;
      wrong.setAttribute('stroke',rgba(COLD,wOp.toFixed(3)));
    }

    // ════ FIGURE MOTION ════
    // travel fraction along the path as a function of p, with a wrong-turn detour.
    // beats 0-2: parked at start (t=0). beat3: start moving. beat4: detour+stall.
    // beat5: resume. beat6: near end. beat7: at goal.
    var travel; // 0..1 along PATH
    var detour=0; // 0..1 sideways toward the wrong-turn dead-end
    var walkAmt=0, headTilt=0, reach=0, lean=0, figGlow=0.85, phase=0;

    if(p<0.42){
      // parked, searching. subtle idle. head down = lost.
      travel=0;
      walkAmt=0;
      headTilt= 0.42 - ramp(p,0.30,0.42)*0.5;   // looks down (lost) → lifts when light appears
      lean=0;
      figGlow=0.8;
    } else if(p<0.55){
      // first steps — tentative, slow
      var l3=(p-0.42)/0.13;
      travel=easeInOut(l3)*0.34;
      walkAmt=easeInOut(l3)*0.9;
      headTilt=-0.1;            // head slightly up, hopeful
      lean=0.14*easeInOut(l3);
      phase=(p*LOOP/1000)*1.4;
    } else if(p<0.64){
      // WRONG TURN — drift toward dead end, slow, then stop & look around
      var l4=(p-0.55)/0.09;
      travel=0.34;             // hold travel (we step sideways instead)
      detour=Math.sin(l4*Math.PI)*1.0;    // out and partway back
      walkAmt=(l4<0.6?0.8:0.2)*(1-l4*0.3);
      headTilt=-0.05 + Math.sin(l4*Math.PI)*0.25; // glance down the wrong way
      lean=0.1;
      phase=(p*LOOP/1000)*1.2;
    } else if(p<0.82){
      // recover & walk the true path with purpose
      var l5=(p-0.64)/0.18;
      travel=0.34 + easeInOut(l5)*0.50;   // 0.34 → 0.84
      detour=(1-easeOut(Math.min(l5*2,1)))*0.0; // detour resolved
      walkAmt=1.0;
      headTilt=-0.12;
      lean=0.2;
      phase=(p*LOOP/1000)*1.7;
    } else if(p<0.90){
      // reach — almost there, arm extends to the light
      var l6=(p-0.82)/0.08;
      travel=0.84 + easeOut(l6)*0.13;     // → 0.97
      walkAmt=1.0-l6*0.7;
      headTilt=-0.3;                      // looking up at the light
      reach=easeInOut(l6);
      lean=0.22;
      phase=(p*LOOP/1000)*1.5;
      figGlow=0.85+l6*0.1;
    } else {
      // clarity — arrived, stands in the light, a breath, glow up
      var l7=(p-0.90)/0.10;
      travel=0.97+easeOut(Math.min(l7*2,1))*0.03;
      walkAmt=0;
      reach=Math.max(0,1-l7*1.6);         // lowers arm slowly
      headTilt=-0.18+Math.sin(l7*Math.PI)* -0.06;
      lean=0.05;
      figGlow=0.9+l7*0.1;
      // gentle breathing handled by bob=0; we add a tiny scale breath below
    }

    // figure position from the path
    var pos=pathPoint(travel);
    // apply detour sideways (perpendicular-ish, toward wrong-turn end at ~ (62,48))
    var fx=pos.x + detour*22;
    var fy=pos.y + detour*30;
    // figure scale shrinks slightly as it moves "into" the depth toward the light
    var sc=1.4 - travel*0.42;
    // breathing at clarity
    if(p>=0.90){ sc += Math.sin((p-0.90)/0.10*Math.PI*2)*0.015; }

    var figG=document.getElementById('sc-fig');
    if(figG){
      var inner=Fig.build({phase:phase, walkAmt:walkAmt, headTilt:headTilt, reach:reach, lean:lean, glow:figGlow, col:col});
      figG.setAttribute('transform','translate('+fx.toFixed(1)+','+fy.toFixed(1)+') scale('+sc.toFixed(3)+')');
      figG.innerHTML=inner;
    }
    // moving shadow under the feet
    var sh=document.getElementById('sc-shadow');
    if(sh){
      sh.setAttribute('cx',fx.toFixed(1));
      sh.setAttribute('cy',(fy+ (42*sc)).toFixed(1));   // under the feet (~ankle depth*scale)
      sh.setAttribute('rx',(30*sc).toFixed(1));
      sh.setAttribute('ry',(5*sc).toFixed(1));
      sh.setAttribute('fill',rgba(col,(0.12*(1-warmth*0.3)).toFixed(3)));
    }

    // ── scene glow swells at clarity ──
    var sg=document.querySelector('.vph-scene-glow');
    if(sg) sg.setAttribute('r',(92+hump(p,0.86,1.0)*34).toFixed(1));

    // ── arrival burst ring ──
    var burst=document.getElementById('sc-burst');
    if(burst){
      var bp=hump(p,0.90,1.0);
      if(bp>0.02){
        var br=(8+bp*60).toFixed(1), bo=(0.5*(1-bp)).toFixed(3);
        burst.setAttribute('opacity','1');
        burst.innerHTML='<circle cx="'+GOAL.x+'" cy="'+GOAL.y+'" r="'+br+'" fill="none" stroke="'+rgba(col,bo)+'" stroke-width="'+(1.6*(1-bp)+0.2).toFixed(2)+'"/>';
      } else { burst.setAttribute('opacity','0'); burst.innerHTML=''; }
    }

    // ── narration on beat change ──
    if(beat!==lastBeat){
      lastBeat=beat;
      var L=ANN[lang()][beat]||ANN.en[beat];
      var aT=document.getElementById('vpAnnTop'), aM=document.getElementById('vpAnnMid'),
          aB=document.getElementById('vpAnnBot'), aG=document.getElementById('vpHperAnn');
      if(aT) aT.textContent=L[0];
      if(aM) aM.textContent=L[1];
      if(aB) aB.textContent=L[2];
      if(aG) aG.style.opacity='1';
    }
  }

  function frame(ts){
    if(!alive) return;
    if(!t0) t0=ts;
    var p=((ts-t0)%LOOP)/LOOP;
    render(p);
    raf=requestAnimationFrame(frame);
  }

  var _domReassert=false;
  function start(){
    var scene=document.getElementById('vpHperScene');
    var label=document.getElementById('vpHperLabel');
    var hint=document.getElementById('vpHperHint');
    var figOld=document.getElementById('vpHperFigure');
    var svg=document.getElementById('heroVPersonSvg');
    if(!scene) return;
    seedMotes();
    scene.innerHTML=scaffold();
    if(figOld) figOld.style.display='none';   // hide the old static figure; we draw our own
    if(svg) svg.classList.add('sc-running');
    if(label){ label.textContent=(lang()==='ar'?'الباحث عن الطريق':'THE SEEKER'); label.style.opacity='1'; }
    if(hint) hint.style.opacity='0';
    lastBeat=-1;
    var isLow=false; try{ isLow=document.documentElement.classList.contains('tier-low'); }catch(e){}
    if(isLow){ render(0.36); alive=false; }
    else { alive=true; t0=0; raf=requestAnimationFrame(frame); }
    // If we started while the page was still loading, other DOMContentLoaded
    // handlers (e.g. the old updateVPerson) might fire afterwards. Re-assert once
    // after load so the cinematic survives any late scene reset.
    if(document.readyState==='loading' && !_domReassert){
      _domReassert=true;
      document.addEventListener('DOMContentLoaded', function(){
        var s=document.getElementById('heroVPersonSvg');
        var sc=document.getElementById('vpHperScene');
        // only re-run if person is still the active version and the scene got emptied
        if(s && s.classList.contains('sc-running') && sc && sc.children.length===0){
          start();
        }
      }, {once:true});
    }
  }

  function stop(){
    alive=false;
    if(raf) cancelAnimationFrame(raf);
    raf=0;
    var svg=document.getElementById('heroVPersonSvg');
    if(svg) svg.classList.remove('sc-running');
    // Clear the cinematic so it doesn't linger when another version is shown.
    var scene=document.getElementById('vpHperScene');
    if(scene) scene.innerHTML='';
    // Hide the leftover annotation/label from the cinematic.
    var ann=document.getElementById('vpHperAnn');
    if(ann) ann.style.opacity='0';
    var figOld=document.getElementById('vpHperFigure');
    if(figOld){ figOld.style.display=''; figOld.setAttribute('transform','translate(0,16) scale(1.45)'); figOld.style.opacity=''; }
  }

  return { start:start, stop:stop, LOOP:LOOP };
})();
