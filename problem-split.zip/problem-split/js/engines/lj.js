const SCENE = (function(){
  let raf=null, running=false, T=0, lastTime=0;
  const smoke=[]; let lastSmoke=0;

  const A1=[
    {name:'WALKING',  start:0,     end:3000},
    {name:'FACING',   start:3000,  end:5500},
    {name:'DESPAIR',  start:5500,  end:8500},
    {name:'WISH',     start:8500,  end:11000},
    {name:'YOU CAN',  start:11000, end:14500},
    {name:'BECOMING', start:14500, end:18500},
  ];
  const A1_END=18500;
  const TRANS_END=20500;
  const A2_BASE=20500;
  const A2=[
    {name:'SETTLING',  start:0,     end:3200},
    {name:'THINKING',  start:3200,  end:6800},
    {name:'CONNECTED', start:6800,  end:10800},
    {name:'SOLVING',   start:10800, end:15800},
  ];
  const A2_END=15800;
  const A3_BASE=A2_BASE+A2_END;     // 36300 — Act 3 starts
  const A3=[
    {name:'GRATITUDE',    start:0,     end:4800},
    {name:'PUSH',         start:4800,  end:9000},
    {name:'BREAKTHROUGH', start:9000,  end:11500},
    {name:'TRIUMPH',      start:11500, end:18500},
  ];
  const A3_END=18500;
  const MW_DUR=7000;                    // moonwalk phase duration
  const MW_START=A3_BASE+A3_END;        // starts right after TRIUMPH
  const TOTAL=MW_START+MW_DUR;          // extended total

  function eio(t){ return t<0.5?2*t*t:1-Math.pow(-2*t+2,2)/2; }
  function lerp(a,b,t){ return a+(b-a)*t; }
  function clamp(v,a,b){ return Math.max(a,Math.min(b,v)); }
  function setLine(id,x1,y1,x2,y2){const el=document.getElementById(id);if(el){el.setAttribute('x1',x1.toFixed(1));el.setAttribute('y1',y1.toFixed(1));el.setAttribute('x2',x2.toFixed(1));el.setAttribute('y2',y2.toFixed(1));}}
  function setCircle(id,cx,cy,r){const el=document.getElementById(id);if(el){el.setAttribute('cx',cx.toFixed(1));el.setAttribute('cy',cy.toFixed(1));if(r!==undefined)el.setAttribute('r',r.toFixed(1));}}
  function setOpacity(id,o){const el=document.getElementById(id);if(el)el.setAttribute('opacity',o.toFixed(2));}
  function setText(id,a,v){const el=document.getElementById(id);if(el)el.setAttribute(a,v);}

  // ════════════════════════════════════════════════════════
  //  UNIFIED FIGURE — one coordinate system for everything.
  //  Standing: head≈405, hip=545, feet=605 (floor=615).
  //  params: ids, x, slump(0-1), facing(±1), step(walk|undef)
  // ════════════════════════════════════════════════════════
  function drawFigure(ids, x, slump, face, step, armUp){
    armUp = armUp||0;
    const headY=405+slump*22, headX=x+face*slump*8;
    const shoulderY=460+slump*14, hipY=545, shoulderX=x+face*slump*4;
    const sw  = step!==undefined?Math.sin(step)*14:0;
    const sw2 = step!==undefined?Math.sin(step+Math.PI)*14:0;
    const handFwd=face*(8+slump*6);
    setCircle(ids.head,headX,headY,19);
    setLine(ids.neck,headX,headY+19,shoulderX,shoulderY);
    setLine(ids.spine,shoulderX,shoulderY,x,hipY);
    // Arms: lerp between hanging (armUp 0) and triumphant V (armUp 1)
    const eRX_h=x+face*14+handFwd*0.3, eRY_h=shoulderY+32, hRX_h=x+face*10+handFwd*0.5, hRY_h=shoulderY+62;
    const eRX_u=x+24, eRY_u=shoulderY-12, hRX_u=x+42, hRY_u=shoulderY-50;
    const eRX=lerp(eRX_h,eRX_u,armUp), eRY=lerp(eRY_h,eRY_u,armUp), hRX=lerp(hRX_h,hRX_u,armUp), hRY=lerp(hRY_h,hRY_u,armUp);
    setLine(ids.armR1,shoulderX,shoulderY+6,eRX,eRY);
    setLine(ids.armR2,eRX,eRY,hRX,hRY);
    const eLX_h=x-face*14+handFwd*0.2, eLY_h=shoulderY+32, hLX_h=x-face*10+handFwd*0.4, hLY_h=shoulderY+62;
    const eLX_u=x-24, eLY_u=shoulderY-12, hLX_u=x-42, hLY_u=shoulderY-50;
    const eLX=lerp(eLX_h,eLX_u,armUp), eLY=lerp(eLY_h,eLY_u,armUp), hLX=lerp(hLX_h,hLX_u,armUp), hLY=lerp(hLY_h,hLY_u,armUp);
    setLine(ids.armL1,shoulderX,shoulderY+6,eLX,eLY);
    setLine(ids.armL2,eLX,eLY,hLX,hLY);
    setLine(ids.legR1,x,hipY,x+face*8+sw*0.4,hipY+35);
    setLine(ids.legR2,x+face*8+sw*0.4,hipY+35,x+face*6+sw,hipY+60);
    setLine(ids.legL1,x,hipY,x-face*8+sw2*0.4,hipY+35);
    setLine(ids.legL2,x-face*8+sw2*0.4,hipY+35,x-face*6+sw2,hipY+60);
    return {headX,headY,shoulderX,shoulderY,x};
  }

  // ════════════════════════════════════════════════════════
  //  MOONWALK — MJ kinematics on same SVG figure
  //  t_local: ms elapsed since MW_START (0 → MW_DUR)
  //  Uses same P ids + setLine/setCircle
  // ════════════════════════════════════════════════════════
  function drawMoonwalk(t_local, now){
    const TURN_DUR = 800;       // ms: pivot from triumph (facing R) to moonwalk (facing L)

    // ── THE MOON rises in (above), glows & breathes ── (always, from t=0)
    const moon=document.getElementById('scMoon');
    if(moon){
      const mIn=eio(Math.min(1,t_local/1200));
      moon.setAttribute('opacity', mIn.toFixed(2));
      const halo=document.getElementById('scMoonHalo');
      if(halo){const pulse=(Math.sin(now/1400)+1)/2; halo.setAttribute('opacity',(mIn*(0.5+pulse*0.25)).toFixed(2)); halo.setAttribute('r',(78+pulse*8).toFixed(1));}
    }

    // ════════════════════════════════════════════════════
    //  PHASE 1 — THE TURN  (0 → TURN_DUR)
    //  Pivot smoothly from facing RIGHT (triumph) to facing LEFT.
    //  Arms lower from the V; passing through face≈0 reads as a turn.
    // ════════════════════════════════════════════════════
    if(t_local < TURN_DUR){
      const tt = eio(t_local / TURN_DUR);          // 0→1
      const faceT = lerp(1, -1, tt);               // +1 → -1 (pivot through 0)
      const armT  = lerp(1, 0, tt);                // arms come down from V
      // standing, no slump, at CENTER_X — feet stay put
      drawFigure(P, CENTER_X, 0, faceT, undefined, armT);
      // hide the front feet lines (drawFigure uses its own legs)
      setOpacity('scFootL', 0); setOpacity('scFootR', 0);
      // aura fades out as triumph ends
      const head=document.getElementById('scHead');
      if(head){const hx=parseFloat(head.getAttribute('cx')),hy=parseFloat(head.getAttribute('cy'));
        setCircle('scAura',hx,hy,28); setText('scAura','stroke',`rgba(var(--cyan),${(0.6*(1-tt)).toFixed(2)})`);}
      setOpacity('scAct3', 1-tt); setOpacity('a3Back', 1);
      const mood=document.getElementById('scMoodGlow'); if(mood) mood.setAttribute('opacity','1');
      return;
    }

    // ════════════════════════════════════════════════════
    //  PHASE 2 — THE MOONWALK  (TURN_DUR → MW_DUR)
    // ════════════════════════════════════════════════════
    const mt       = t_local - TURN_DUR;                 // moonwalk-local time
    const MW_RUN   = MW_DUR - TURN_DUR;                  // run length
    const progress = mt / MW_RUN;
    const CYCLE    = 1300;                                // 1.3s per glide step
    const phase    = (mt % CYCLE) / CYCLE;               // 0→1 per cycle
    const transIn  = 1;                                  // arms already settled in the turn

    setOpacity('scAura', 0);
    setOpacity('scFootL', 1); setOpacity('scFootR', 1);
    setOpacity('scAct3', 0); setOpacity('a3Back', 1);
    const _rg=document.getElementById('scRising');
    if(_rg && !_rg._mwInit){ _rg._mwInit=true; _rg._parts=[]; }

    // ── Body glides smoothly. Facing LEFT. ──
    // KEY: the upper body stays VERY stable & smooth — that's the moonwalk magic.
    // CONSTANT speed (linear, NO easing). Starts at CENTER_X (matches the turn).
    const gx = CENTER_X + progress * 55;                 // linear, gentle, no jump
    const hipY = 545, floor = 615, shoulderY = 458;
    const face = -1;                                     // facing LEFT
    const lean = 14;                                      // steady forward lean

    // Almost no vertical motion — only a whisper of glide-float at STEP rate
    // (2 steps per cycle → use phase*2 so it syncs with the feet, tiny amplitude)
    const floatY = Math.sin(phase*Math.PI*4) * -1;        // ±1px only, step-synced
    // No hip sway — torso rock-steady (sway breaks the illusion)
    const hipX = gx;

    // ── HEAD + TORSO — stable, gentle constant lean ──
    const shoulderX = hipX + face*lean;
    const headX = hipX + face*(lean+5);
    const headY = 404 + floatY;
    setCircle(P.head, headX, headY, 18);
    setLine(P.neck,  headX, 422 + floatY, shoulderX, shoulderY + floatY);
    setLine(P.spine, shoulderX, shoulderY + floatY, hipX, hipY + floatY);

    // ── FEDORA HAT — sits ON TOP of the head, follows it exactly ──
    (function(){
      const hat=document.getElementById('scHat'); if(!hat) return;
      hat.setAttribute('opacity', Math.min(1, mt/300).toFixed(2));
      const brim=document.getElementById('scHatBrim');
      const crown=document.getElementById('scHatCrown');
      const R = 18;                       // head radius
      // Hat rests on the crown of the head. Head center=(headX,headY), top=headY-R.
      const tx = headX + face*3;          // shifted slightly toward facing (cocked)
      const brimY = headY - R + 3;        // brim sits just at the top of the head
      const tilt  = face*4;               // brim dips toward facing side
      if(brim){
        // Brim: a wide shallow arc resting on the head's crown
        brim.setAttribute('d',
          `M ${(tx-23).toFixed(1)} ${(brimY+tilt*0.35).toFixed(1)} `+
          `Q ${tx.toFixed(1)} ${(brimY-3).toFixed(1)} `+
          `${(tx+23).toFixed(1)} ${(brimY-tilt*0.35).toFixed(1)}`);
      }
      if(crown){
        // Crown: dome sitting ON the brim (above it)
        const cw=12, ch=16;
        const baseY = brimY - 1;          // crown base = just above brim
        crown.setAttribute('d',
          `M ${(tx-cw).toFixed(1)} ${(baseY+tilt*0.25).toFixed(1)} `+
          `L ${(tx-cw+3).toFixed(1)} ${(baseY-ch).toFixed(1)} `+
          `L ${(tx+cw-3).toFixed(1)} ${(baseY-ch).toFixed(1)} `+
          `L ${(tx+cw).toFixed(1)} ${(baseY-tilt*0.25).toFixed(1)} Z`);
      }
    })();

    // ── MOONLIGHT spotlight: soft beam BEHIND the dancer, pool on floor ──
    (function(){
      const beamIn = Math.min(1, mt/500);
      const beam=document.getElementById('scMoonBeam');
      const pool=document.getElementById('scMoonPool');
      const flick=0.85+Math.sin(now/900)*0.15;     // gentle light flicker
      if(beam){
        // narrower cone from moon → floor, centered on dancer (behind him)
        beam.setAttribute('points',
          `195,150 ${(gx-70).toFixed(0)},615 ${(gx+70).toFixed(0)},615`);
        beam.setAttribute('opacity', (beamIn*0.4*flick).toFixed(2));   // soft, not foggy
      }
      if(pool){
        // bright pool of moonlight on the floor under the dancer
        pool.setAttribute('cx', gx.toFixed(1));
        pool.setAttribute('opacity', (beamIn*(0.16+Math.sin(now/900)*0.04)).toFixed(2));
      }
    })();

    // ── ARMS — profile: near arm swings in front, far arm stays BEHIND ──
    // (arms already settled from the turn, so use fixed rest geometry)
    const sw = Math.sin(phase*Math.PI*2) * 9;
    // FRONT (near) arm = LEFT — clearly in front, natural pendulum
    const fElX = shoulderX + face*9 + sw*0.35, fElY = shoulderY + 28 + floatY;
    const fHaX = shoulderX + face*5 + sw*0.6,  fHaY = shoulderY + 64 + floatY;
    setLine(P.armL1, shoulderX, shoulderY+6+floatY, fElX, fElY);
    setLine(P.armL2, fElX, fElY, fHaX, fHaY);
    // BACK (far) arm = RIGHT — stays on the back side (right of spine), subtle opposite swing
    const bElX = shoulderX + 14 - sw*0.3,  bElY = shoulderY + 26 + floatY;
    const bHaX = shoulderX + 18 - sw*0.45, bHaY = shoulderY + 58 + floatY;
    setLine(P.armR1, shoulderX + 4, shoulderY+6+floatY, bElX, bElY);
    setLine(P.armR2, bElX, bElY, bHaX, bHaY);


    // ════════════════════════════════════════════════════
    //  LEGS — TRUE MJ MOONWALK (continuous, no jumps)
    //
    //  Correct mechanic:
    //   • FLAT foot SLIDES backward along the floor  → the visible glide
    //   • TOE foot (heel HIGH) drags forward like a step
    //   • Both feet move continuously (triangle wave, half-cycle apart)
    //   • Roles swap smoothly — flat↔toe — no teleport
    // ════════════════════════════════════════════════════
    const FOOT = 18;          // foot length (toe points LEFT, face=-1)
    const HEEL_LIFT = 20;     // heel height when on toe (steep = MJ)
    const FRONT = -18;        // foot relative-X at front (left)
    const BACK  =  20;        // foot relative-X at back (right)
    let slideToeX = gx;

    // foot state for a given per-foot phase p (0→1)
    //   p in [0,0.5): FLAT, sliding back  FRONT → BACK   (the visible glide)
    //   p in [0.5,1): TOE step — LIFT, then MOVE (while up), then PLACE
    //                 → horizontal motion happens ONLY while lifted = NO skating
    function footState(p){
      if(p < 0.5){
        const s = p/0.5;                       // linear slide = perfectly smooth glide
        return { relX: lerp(FRONT, BACK, s), flat:true, raise:0 };
      } else {
        const s = (p-0.5)/0.5;                 // 0→1 over the toe phase
        let raise, mv;
        if(s < 0.28){
          // 1) heel LIFTS — foot stays put at BACK
          raise = eio(s/0.28);
          mv = 0;
        } else if(s < 0.72){
          // 2) MOVE forward BACK→FRONT while fully lifted (in the air)
          raise = 1;
          mv = eio((s-0.28)/0.44);
        } else {
          // 3) heel SETS DOWN at FRONT — foot stays put
          raise = eio(1-(s-0.72)/0.28);
          mv = 1;
        }
        return { relX: lerp(BACK, FRONT, mv), flat:false, raise };
      }
    }

    const aP = phase;                          // LEFT foot phase
    const bP = (phase + 0.5) % 1;              // RIGHT foot phase (half offset)
    const A = footState(aP);
    const B = footState(bP);

    // Stance shifted toward the lean so feet sit under the body's center of mass
    // (body leans forward by `lean`; without this the figure looks like it's toppling).
    const legBaseX = hipX + face*8;

    // Draw one leg + foot given state, into the given ids
    // Build the FOOT first, then connect ankle → shin → knee → hip
    // so nothing detaches.
    function drawLeg(leg1, leg2, footId, st){
      const baseX = legBaseX + st.relX;      // ground ref, balanced under the lean
      let toeX, toeY, heelX, heelY, ankX, ankY;

      if(st.flat){
        // FLAT foot on floor — toe LEFT, heel RIGHT, both on floor
        toeX  = baseX + face*FOOT*0.6;  toeY  = floor;
        heelX = baseX - face*FOOT*0.4;  heelY = floor;
        // ankle sits right above the foot, ON it
        ankX  = baseX;                  ankY  = floor;
      } else {
        // TOE foot — toe LEFT on floor (pivot), heel RIGHT raised up
        toeX  = baseX + face*FOOT*0.6;  toeY  = floor;
        heelX = baseX - face*FOOT*0.4;  heelY = floor - st.raise*HEEL_LIFT;
        // ankle lies ON the heel→toe line (≈60% toward heel) — stays attached
        ankX  = lerp(toeX, heelX, 0.6);
        ankY  = lerp(toeY, heelY, 0.6);
      }

      // Knee: natural forward bend (toward facing dir = left)
      const knX = lerp(hipX, ankX, 0.5) + face*6;
      const knY = lerp(hipY+floatY, ankY, 0.5) + 5;

      setLine(leg1, hipX, hipY+floatY, knX, knY);   // thigh: hip → knee
      setLine(leg2, knX, knY, ankX, ankY);          // shin: knee → ankle (on foot)
      setLine(footId, heelX, heelY, toeX, toeY);    // foot: heel → toe
      return {ankX, toeX, flat:st.flat};
    }

    const legA = drawLeg(P.legL1, P.legL2, 'scFootL', A);
    const legB = drawLeg(P.legR1, P.legR2, 'scFootR', B);

    // The glow follows whichever foot is FLAT + sliding (the glide foot)
    const glideFoot = A.flat ? legA : legB;
    slideToeX = glideFoot.toeX;

    // ── Foot sparkle/glow under the sliding toe ──
    const fg = document.getElementById('scMoonGlow');
    if(fg){
      fg.setAttribute('cx', slideToeX.toFixed(1));
      fg.setAttribute('cy', (floor-3).toFixed(1));
      fg.setAttribute('r', (6 + Math.sin(now/200)*2).toFixed(1));
      fg.setAttribute('opacity', (0.5 + Math.sin(now/260)*0.22).toFixed(2));
    }
    // glide trail BEHIND the dancer — he travels RIGHT, so the trail
    // streams to the LEFT (where he came from).
    const trail = document.getElementById('scMoonTrail');
    if(trail){
      trail.setAttribute('x1', (slideToeX - 100).toFixed(1));  // far behind (left)
      trail.setAttribute('y1', floor.toFixed(1));
      trail.setAttribute('x2', (slideToeX - 4).toFixed(1));    // near the foot
      trail.setAttribute('y2', floor.toFixed(1));
      trail.setAttribute('opacity', Math.min(0.34, progress*0.5).toFixed(2));
    }

    // ── MAGIC: sparkles drifting up around the dancer ──
    (function(){
      const rg=document.getElementById('scRising'); if(!rg) return;
      if(!rg._mw) rg._mw=[];
      const arr=rg._mw;
      if(Math.random()<0.4) arr.push({x:gx+(Math.random()-0.5)*70, y:floor-Math.random()*120, vy:-(0.4+Math.random()*0.8), vx:(Math.random()-0.5)*0.4, life:1, r:0.6+Math.random()*1.6, ph:Math.random()*6});
      let hh='';
      for(let i=arr.length-1;i>=0;i--){const p=arr[i];p.x+=p.vx+Math.sin(now/700+p.ph)*0.3;p.y+=p.vy;p.life-=0.011;if(p.life<=0){arr.splice(i,1);continue;}
        const a=(p.life*0.6).toFixed(2);
        hh+=`<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="${p.r.toFixed(1)}" fill="rgba(var(--cyan),${a})"/>`;}
      rg.innerHTML=hh;
    })();

    // gentle moonlit mood
    const mood=document.getElementById('scMoodGlow'); if(mood) mood.setAttribute('opacity','1');

    // ── CAPTION ──
    if(mt > 200) setCaption('كل خطوة للخلف هي بداية للأمام', true);
  }

  // ── Figure id maps + mirror geometry (restored) ──
  const P={head:'scHead',neck:'scNeck',spine:'scSpine',armR1:'scArmR1',armR2:'scArmR2',armL1:'scArmL1',armL2:'scArmL2',legR1:'scLegR1',legR2:'scLegR2',legL1:'scLegL1',legL2:'scLegL2'};
  const R={head:'rfHead',neck:'rfNeck',spine:'rfSpine',armR1:'rfArmR1',armR2:'rfArmR2',armL1:'rfArmL1',armL2:'rfArmL2',legR1:'rfLegR1',legR2:'rfLegR2',legL1:'rfLegL1',legL2:'rfLegL2'};
  const GLASS_X=515;
  const STAND_X=445;
  const REFLECT_X=2*GLASS_X-STAND_X;

  function drawSeated(x, sit, now){
    // sit: 0 = standing (== drawFigure standing), 1 = seated on chair
    // Standing reference points (from drawFigure at slump 0):
    const S={ headX:x, headY:405, shoulderY:460, hipX:x, hipY:545,
      eRX:x+16.4, eRY:492, hRX:x+14, hRY:522, eLX:x-12.4, eLY:492, hLX:x-7.2, hLY:522,
      kRX:x+8, kRY:580, fRX:x+6, fRY:605, kLX:x-8, kLY:580, fLX:x-6, fLY:605 };
    // Seated reference (hip on chair seat, knees forward, hands up for phone/cig)
    const C={ headX:x-2, headY:420, shoulderY:475, hipX:x, hipY:552,
      eRX:x+18, eRY:500, hRX:x+22, hRY:458, eLX:x-18, eLY:500, hLX:x-14, hLY:448,
      kRX:x+42, kRY:556, fRX:x+48, fRY:608, kLX:x+30, kLY:556, fLX:x+36, fLY:608 };
    const k=eio(sit);
    const L=(a,b)=>lerp(a,b,k);
    const headX=L(S.headX,C.headX), headY=L(S.headY,C.headY);
    const shoulderY=L(S.shoulderY,C.shoulderY), hipY=L(S.hipY,C.hipY), hipX=x;
    setCircle('scHead',headX,headY,19);
    setLine('scNeck',headX,headY+19,hipX,shoulderY);
    setLine('scSpine',hipX,shoulderY,hipX,hipY);
    const eRX=L(S.eRX,C.eRX),eRY=L(S.eRY,C.eRY),hRX=L(S.hRX,C.hRX),hRY=L(S.hRY,C.hRY);
    const eLX=L(S.eLX,C.eLX),eLY=L(S.eLY,C.eLY),hLX=L(S.hLX,C.hLX),hLY=L(S.hLY,C.hLY);
    setLine('scArmR1',hipX,shoulderY+6,eRX,eRY); setLine('scArmR2',eRX,eRY,hRX,hRY);
    setLine('scArmL1',hipX,shoulderY+6,eLX,eLY); setLine('scArmL2',eLX,eLY,hLX,hLY);
    const kRX=L(S.kRX,C.kRX),kRY=L(S.kRY,C.kRY),fRX=L(S.fRX,C.fRX),fRY=L(S.fRY,C.fRY);
    const kLX=L(S.kLX,C.kLX),kLY=L(S.kLY,C.kLY),fLX=L(S.fLX,C.fLX),fLY=L(S.fLY,C.fLY);
    setLine('scLegR1',hipX,hipY,kRX,kRY); setLine('scLegR2',kRX,kRY,fRX,fRY);
    setLine('scLegL1',hipX,hipY,kLX,kLY); setLine('scLegL2',kLX,kLY,fLX,fLY);
    return {headX,headY,handRX:hRX,handRY:hRY,handLX:hLX,handLY:hLY,hipX};
  }

  function frame(now){
    if(!running) return;
    if(!lastTime) lastTime=now;
    const dt=Math.min(50,now-lastTime); lastTime=now;
    T=(T+dt)%TOTAL;
    setOpacity('scFootL',0); setOpacity('scFootR',0);
    if(T < A1_END){ drawAct1(T, now); }
    else if(T < TRANS_END){ drawTransition((T-A1_END)/(TRANS_END-A1_END), now); }
    else if(T < A3_BASE){ drawAct2(T-A2_BASE, now); }
    else if(T < MW_START){ drawAct3(T-A3_BASE, now); }
    else { drawMoonwalk(T-MW_START, now); }
    raf=requestAnimationFrame(frame);
  }

  // ════════ ACT 1: THE MIRROR ════════
  function drawAct1(t, now){
    setOpacity('scAct2', 0); setOpacity('scMirror', 1);
    setOpacity('scAct3', 0); setOpacity('a3Back', 0);  // hide Act3 on every Act1 frame
    const ph=A1.find(p=>t>=p.start&&t<p.end)||A1[0];
    const lt=clamp((t-ph.start)/(ph.end-ph.start),0,1);
    let px,pslump,pstep,pAura=0;
    let rfVisible=0,rfSlump=1,rfAura=0,rfTransform=0;
    let speechA=0,speechTxt='I feel like a failure.',replyA=0,moodBright=0;

    if(ph.name==='WALKING'){ px=lerp(180,STAND_X,eio(lt)); pslump=0.5; pstep=t/120; }
    else if(ph.name==='FACING'){ px=STAND_X; pslump=lerp(0.5,0.85,eio(lt)); rfVisible=eio(lt); rfSlump=pslump; }
    else if(ph.name==='DESPAIR'){ px=STAND_X; pslump=0.9; rfVisible=1; rfSlump=0.9;
      speechA=eio(clamp(lt/0.3,0,1))*(lt<0.85?1:eio(1-(lt-0.85)/0.15)); speechTxt='I feel like a failure.'; moodBright=-0.02; }
    else if(ph.name==='WISH'){ px=STAND_X; pslump=lerp(0.9,0.78,eio(lt)); rfVisible=1; rfSlump=lerp(0.9,0.78,eio(lt));
      speechA=eio(clamp(lt/0.3,0,1))*(lt<0.85?1:eio(1-(lt-0.85)/0.15)); speechTxt='...I want to change.'; rfAura=eio(lt)*0.3; moodBright=0.01; }
    else if(ph.name==='YOU CAN'){ px=STAND_X; pslump=0.78; rfVisible=1; rfTransform=eio(lt); rfSlump=lerp(0.78,0,rfTransform); rfAura=0.3+rfTransform*0.7;
      replyA=eio(clamp((lt-0.2)/0.3,0,1))*(lt<0.9?1:eio(1-(lt-0.9)/0.1)); moodBright=0.02+rfTransform*0.06; }
    else if(ph.name==='BECOMING'){ px=STAND_X; const tr=eio(lt); pslump=lerp(0.78,0,tr); pAura=tr*0.9; rfVisible=lerp(1,0.5,tr); rfSlump=0; rfAura=1-tr*0.4; moodBright=0.08+tr*0.10; }

    const pinfo=drawFigure(P, px, pslump, 1, pstep);
    setCircle('scAura',pinfo.headX,pinfo.headY,pAura>0?(28+pAura*16):0);
    setText('scAura','stroke',`rgba(var(--cyan),${(pAura*0.5).toFixed(2)})`);

    setOpacity('scReflection',rfVisible);
    if(rfVisible>0.02){
      // TRUE MIRROR: reflection at REFLECT_X, facing -1, SAME slump → same height
      const rinfo=drawFigure(R, REFLECT_X, rfSlump, -1, undefined);
      const baseCols={rfHead:0.6};
      ['rfHead','rfNeck','rfSpine','rfArmR1','rfArmR2','rfArmL1','rfArmL2','rfLegR1','rfLegR2','rfLegL1','rfLegL2'].forEach(id=>{
        const el=document.getElementById(id); if(el){ const base=(id==='rfHead')?0.6:0.55; const a=base+rfTransform*0.35; el.setAttribute('stroke',`rgba(var(--cyan),${Math.min(0.98,a).toFixed(2)})`);} });
      setCircle('rfAura',rinfo.headX,rinfo.headY,rfAura>0?(24+rfAura*18):0);
      setText('rfAura','stroke',`rgba(var(--cyan),${(rfAura*0.6).toFixed(2)})`);
    }
    setOpacity('scSpeech',speechA);
    const spEl=document.getElementById('scSpeech');
    if(spEl){ spEl.textContent=speechTxt; spEl.setAttribute('fill',`rgba(var(--ice),${(speechA*0.85).toFixed(2)})`); }
    setOpacity('scReply',replyA);
    const rpEl=document.getElementById('scReply');
    if(rpEl) rpEl.setAttribute('fill',`rgba(var(--cyan),${(replyA*0.9).toFixed(2)})`);
    const halo=document.getElementById('scMirrorHalo');
    if(halo){ const pulse=(Math.sin(now/900)+1)/2; let hb=0.25+rfTransform*0.5+(ph.name==='BECOMING'?0.3:0); halo.setAttribute('opacity',(hb*0.7+pulse*0.05).toFixed(2)); }
    const mood=document.getElementById('scMoodGlow');
    if(mood) mood.setAttribute('opacity',(0.5+moodBright*4).toFixed(2));
    risingLight(ph.name==='BECOMING'&&lt>0.1, STAND_X, 480, now);
    const C={'WALKING':'a quiet evening, alone','FACING':'face to face with yourself','DESPAIR':'the weight of feeling not enough','WISH':'a small, honest wish','YOU CAN':'your other self answers','BECOMING':'you follow who you can become'};
    setCaption(C[ph.name], (ph.name==='YOU CAN'||ph.name==='BECOMING'));
  }

  // ════════ TRANSITION: mirror fades, person walks to center (seamless) ════════
  function drawTransition(t, now){
    const k=eio(t);
    setOpacity('scAct3', 0); setOpacity('a3Back', 0);
    setOpacity('scMirror', 1-k);
    setOpacity('scReflection', (1-k)*0.5);
    setOpacity('scSpeech',0); setOpacity('scReply',0);
    setOpacity('scMirrorHalo', (1-k)*0.3);
    const px=lerp(STAND_X,350,k);
    const pinfo=drawFigure(P, px, 0, 1, t*30);      // standing, walking
    setCircle('scAura',pinfo.headX,pinfo.headY, (1-k)*44);
    setText('scAura','stroke',`rgba(var(--cyan),${((1-k)*0.4).toFixed(2)})`);
    setOpacity('scAct2', k*0.3);
    setCaption('a new day begins', true);
  }

  // ════════ ACT 2: A DAY WITH PROBLEM ════════
  function drawAct2(t, now){
    setOpacity('scMirror',0); setOpacity('scReflection',0); setOpacity('scAura',0);
    setOpacity('scAct2',1);
    const ph=A2.find(p=>t>=p.start&&t<p.end)||A2[0];
    const lt=clamp((t-ph.start)/(ph.end-ph.start),0,1);

    // sit amount: 0 during settle-start → 1 seated
    let sit = (ph.name==='SETTLING') ? eio(lt) : 1;
    const seat=drawSeated(350, sit, now);
    let pose={headX:seat.headX,headY:seat.headY,handRX:seat.handRX,handRY:seat.handRY,handLX:seat.handLX,handLY:seat.handLY,hipX:seat.hipX};

    // emotional head lift at solving
    (function(){const head=document.getElementById('scHead');if(!head)return;let d=0;
      if(ph.name==='SOLVING')d=-eio(lt)*6;
      const hy=parseFloat(head.getAttribute('cy'))+d;head.setAttribute('cy',hy.toFixed(1));pose.headY=hy;})();

    // window sky
    (function(){const sky=document.getElementById('a2Sky'),stars=document.getElementById('a2Stars'),rain=document.getElementById('a2Rain');if(!sky)return;
      const gp=t/A2_END; const stormy=Math.max(0,1-gp*1.4); const clear=Math.min(1,Math.max(0,(gp-0.5)*2));
      sky.setAttribute('fill',`rgba(${Math.round(20+clear*5)},${Math.round(28+clear*12)},${Math.round(45+clear*40)},0.6)`);
      if(stars){stars.setAttribute('opacity',clear.toFixed(2));if(!stars._b){stars._b=1;let hh='';for(let i=0;i<14;i++){hh+=`<circle cx="${(605+Math.random()*140).toFixed(0)}" cy="${(125+Math.random()*190).toFixed(0)}" r="${(0.5+Math.random()).toFixed(1)}" fill="rgba(220,235,255,0.8)"/>`;}stars.innerHTML=hh;}
        stars.querySelectorAll('circle').forEach((c,i)=>{const tw=(Math.sin(now/700+i*1.3)+1)/2;c.setAttribute('opacity',(0.3+tw*0.6).toFixed(2));});}
      if(rain){rain.setAttribute('opacity',(stormy*0.5).toFixed(2));if(stormy>0.1){let hh='';for(let i=0;i<10;i++){const rx=605+((i*23+now*0.15)%140),ry=125+((i*40+now*0.4)%190);hh+=`<line x1="${rx.toFixed(0)}" y1="${ry.toFixed(0)}" x2="${(rx-3).toFixed(0)}" y2="${(ry+10).toFixed(0)}" stroke="rgba(150,180,220,0.3)" stroke-width="0.8"/>`;}rain.innerHTML=hh;}else rain.innerHTML='';}})();

    // dust
    (function(){const dust=document.getElementById('a2Dust');if(!dust)return;if(!dust._m){dust._m=[];for(let i=0;i<16;i++)dust._m.push({x:220+Math.random()*360,y:150+Math.random()*400,sp:0.1+Math.random()*0.2,phase:Math.random()*6,r:0.4+Math.random()*0.8});}
      let hh='';dust._m.forEach(m=>{m.y-=m.sp;if(m.y<140){m.y=560;m.x=220+Math.random()*360;}const dr=Math.sin(now/2000+m.phase)*8;const a=(0.12+Math.sin(now/1500+m.phase)*0.05).toFixed(3);hh+=`<circle cx="${(m.x+dr).toFixed(1)}" cy="${m.y.toFixed(1)}" r="${m.r}" fill="rgba(var(--ice),${a})"/>`;});dust.innerHTML=hh;})();

    // chair + desk fade in during settling
    const settleIn=(ph.name==='SETTLING')?eio(clamp(lt/0.5,0,1)):1;
    setOpacity('a2Chair',settleIn);
    setOpacity('a2Desk',settleIn);
    {const steam=document.getElementById('a2Steam');if(steam&&settleIn>0.1){const sw=Math.sin(now/800)*3;steam.setAttribute('d',`M 466,482 Q ${464+sw},476 ${467+sw*1.5},470`);}
      const lg=document.getElementById('a2LampGlow');if(lg){let lb=0.3;if(ph.name==='CONNECTED')lb=0.3+eio(lt)*0.3;else if(ph.name==='SOLVING')lb=0.6+eio(lt)*0.4;const pulse=(Math.sin(now/900)+1)/2;lg.setAttribute('rx',(40+lb*30).toFixed(0));lg.setAttribute('ry',(25+lb*18).toFixed(0));lg.setAttribute('opacity',(settleIn*(lb*0.5+pulse*0.05)).toFixed(2));}}

    // tangled thoughts → eye
    (function(){const tEl=document.getElementById('a2Thoughts');if(!tEl)return;
      const thoughtsVis=(ph.name!=='SOLVING'||lt<0.7) && sit>0.4;
      let resolve=0;if(ph.name==='CONNECTED')resolve=eio(lt)*0.5;else if(ph.name==='SOLVING')resolve=0.5+eio(lt)*0.5;
      const hx=pose.headX,hy=pose.headY-19-18;const pts=[];const NPT=10;
      for(let i=0;i<=NPT;i++){const t2=i/NPT;const cx=Math.sin(t2*Math.PI*5+now/700)*22*(1-resolve);const cy=Math.cos(t2*Math.PI*4+now/600)*14*(1-resolve);const lx=(t2-0.5)*8*resolve;const ly=-t2*55*resolve;pts.push((hx+cx+lx).toFixed(1)+','+(hy+cy+ly-t2*18).toFixed(1));}
      tEl.setAttribute('d','M '+pts.join(' L '));const ta=(0.4+resolve*0.3);tEl.setAttribute('stroke',resolve>0.5?`rgba(var(--cyan),${ta.toFixed(2)})`:`rgba(var(--ice),${ta.toFixed(2)})`);
      setOpacity('a2Thoughts',thoughtsVis?1:0);
      if(ph.name==='SOLVING'&&lt>0.4){const sparkT=eio((lt-0.4)/0.6);const sp=document.getElementById('a2ClaritySpark');if(sp){sp.setAttribute('cx',hx.toFixed(1));sp.setAttribute('cy',(hy-70).toFixed(1));sp.setAttribute('r',(sparkT*18).toFixed(1));sp.setAttribute('opacity',(sparkT*0.5).toFixed(2));}
        const eye=document.getElementById('a2Eye');if(eye){const eT=eio(clamp((lt-0.55)/0.45,0,1));eye.setAttribute('opacity',eT.toFixed(2));eye.setAttribute('transform',`translate(${(hx-350).toFixed(1)},${(hy-70-150).toFixed(1)}) scale(${(0.7+eT*0.3).toFixed(2)})`);
          const pupil=document.getElementById('a2EyePupil');if(pupil){const pl=(Math.sin(now/400)+1)/2;pupil.setAttribute('r',(3+pl*2).toFixed(1));}
          const esh=document.getElementById('a2EyeShape');if(esh){let sy=1;if(lt>0.72&&lt<0.80){const bt=(lt-0.72)/0.08;sy=1-(1-Math.abs(Math.sin(bt*Math.PI)))*0.9;}esh.setAttribute('transform',`translate(350,150) scale(1,${sy.toFixed(2)}) translate(-350,-150)`);}}}
      else{setOpacity('a2ClaritySpark',0);setOpacity('a2Eye',0);}})();

    // cigarette + smoke (THINKING+)
    const cigV=(['THINKING','CONNECTED','SOLVING'].includes(ph.name))?1:0;
    setOpacity('a2Cigarette',cigV);
    if(cigV){setLine('a2CigStick',pose.handLX,pose.handLY,pose.handLX-7,pose.handLY-7);setCircle('a2CigTip',pose.handLX-7,pose.handLY-7,1.8);
      if(now-lastSmoke>180){lastSmoke=now;smoke.push({x:pose.handLX-7,y:pose.handLY-7,vx:(Math.random()-0.5)*0.3,vy:-0.5-Math.random()*0.4,life:1.0,r:1+Math.random()*1.5,phase:Math.random()*6});}}
    const sg=document.getElementById('a2Smoke');
    if(sg){let hh='';for(let i=smoke.length-1;i>=0;i--){const s=smoke[i];s.x+=s.vx+Math.sin(now/500+s.phase)*0.3;s.y+=s.vy;s.life-=0.008;s.r+=0.04;if(s.life<=0){smoke.splice(i,1);continue;}hh+=`<circle cx="${s.x.toFixed(1)}" cy="${s.y.toFixed(1)}" r="${s.r.toFixed(1)}" fill="rgba(var(--ice),${(s.life*0.25).toFixed(3)})"/>`;}sg.innerHTML=hh;}

    // phone (CONNECTED+)
    const phoneV=(['CONNECTED','SOLVING'].includes(ph.name))?1:0;
    setOpacity('a2Phone',phoneV);
    if(phoneV){const pb=document.getElementById('a2PhoneBody'),pl=document.getElementById('a2PhoneLight');
      if(pb){pb.setAttribute('x',(pose.handRX-7).toFixed(1));pb.setAttribute('y',(pose.handRY-11).toFixed(1));}
      if(pl){pl.setAttribute('cx',pose.handRX.toFixed(1));pl.setAttribute('cy',pose.handRY.toFixed(1));let pulse=(Math.sin(now/500)+1)/2;let burst=0;if(ph.name==='SOLVING'&&lt<0.2)burst=eio(1-lt/0.2)*0.6;pl.setAttribute('opacity',(0.4+pulse*0.4+burst).toFixed(2));pl.setAttribute('r',(14+burst*12).toFixed(1));}}

    // chat (CONNECTED+)
    const chatV=(['CONNECTED','SOLVING'].includes(ph.name))?1:0;
    setOpacity('a2Chat',chatV);
    if(chatV){
      if(ph.name==='CONNECTED'){setOpacity('a2Bubble1',eio(clamp(lt/0.35,0,1)));setOpacity('a2Typing',(lt>0.45&&lt<0.95)?1:0);setOpacity('a2Bubble2',0);setOpacity('a2Bubble3',0);}
      else{setOpacity('a2Bubble1',1);setOpacity('a2Typing',lt<0.15?1-lt/0.15:0);setOpacity('a2Bubble2',eio(clamp((lt-0.1)/0.3,0,1)));setOpacity('a2Bubble3',eio(clamp((lt-0.55)/0.3,0,1)));}
      const ty=document.getElementById('a2Typing');if(ty&&parseFloat(ty.getAttribute('opacity'))>0.1){[1,2,3].forEach(n=>{const d=document.getElementById('a2Dot'+n);if(d){const b=(Math.sin(now/250-n*0.6)+1)/2;d.setAttribute('cy',(243-b*2.5).toFixed(1));d.setAttribute('fill',`rgba(var(--cyan),${(0.4+b*0.4).toFixed(2)})`);}});}}

    // fragments lift away at solving
    (function(){const fg=document.getElementById('a2Fragments');if(!fg)return;let lift=0;if(ph.name==='SOLVING')lift=eio(lt);else if(ph.name==='CONNECTED')lift=eio(lt)*0.3;const fa=Math.max(0,(1-lift*1.3))*(sit>0.5?1:0);
      if(!fg._f){fg._f=[];[[250,560],[300,585],[420,560],[460,585],[245,520],[470,520]].forEach((p,i)=>fg._f.push({bx:p[0],by:p[1],rot:i*40,phase:i*1.1}));}
      if(fa>0.02){let hh='';fg._f.forEach(f=>{const dr=Math.sin(now/1500+f.phase)*3;const x=f.bx+dr,y=f.by-lift*120,rot=f.rot+lift*60+Math.sin(now/2000+f.phase)*5;hh+=`<g transform="translate(${x.toFixed(1)},${y.toFixed(1)}) rotate(${rot.toFixed(0)})" opacity="${(fa*0.3).toFixed(3)}"><path d="M -8,-5 L 8,-3 L -6,2 L 7,5" fill="none" stroke="rgba(var(--id),0.6)" stroke-width="1" stroke-linecap="round"/></g>`;});fg.innerHTML=hh;}else fg.innerHTML='';})();

    risingLight(ph.name==='SOLVING'&&lt>0.4, pose.hipX, 480, now);

    const mood=document.getElementById('scMoodGlow');
    if(mood){let b=0.04;if(ph.name==='CONNECTED')b=0.04+eio(lt)*0.04;else if(ph.name==='SOLVING')b=0.08+eio(lt)*0.10;mood.setAttribute('opacity',(0.5+b*3).toFixed(2));}

    const STORY={'SETTLING':'sitting with it','THINKING':'lost in thought','CONNECTED':'reaching out','SOLVING':'now it is clear'};
    setCaption(STORY[ph.name], ph.name==='SOLVING');
  }

  // ════════ ACT 3: THE BREAKTHROUGH (cinematic) ════════
  const CENTER_X=350, CENTER_Y=475;   // energy center at the hero's chest
  function drawAct3(t, now){
    setOpacity('scMirror',0); setOpacity('scReflection',0);
    const ph=A3.find(p=>t>=p.start&&t<p.end)||A3[0];
    const lt=clamp((t-ph.start)/(ph.end-ph.start),0,1);

    // Act2 fades out during gratitude; Act3 layers fade in
    let a2fade=(ph.name==='GRATITUDE')?Math.max(0,1-eio(clamp(lt/0.5,0,1))):0;
    setOpacity('scAct2', a2fade);
    setOpacity('scAct3', (ph.name==='GRATITUDE')?eio(clamp(lt/0.45,0,1)):1);
    setOpacity('a3Back', (ph.name==='GRATITUDE')?0:1);

    // ── PERSON ──
    let armUp=0, aura=0;
    if(ph.name==='GRATITUDE'){
      const sit=1-eio(clamp(lt/0.55,0,1));   // stand up (continuous from Act2 seated)
      drawSeated(CENTER_X, sit, now);
    } else if(ph.name==='PUSH'){
      drawFigure(P, CENTER_X, 0, 1, undefined, 0);   // standing, focused
      aura=0.2+eio(lt)*0.2;
    } else if(ph.name==='BREAKTHROUGH'){
      armUp=eio(clamp((lt-0.25)/0.5,0,1));    // arms shoot up
      drawFigure(P, CENTER_X, 0, 1, undefined, armUp);
      aura=0.5+eio(lt)*0.4;
    } else if(ph.name==='TRIUMPH'){
      armUp=1;
      const breathe=Math.sin(now/900)*0.02;
      drawFigure(P, CENTER_X, 0, 1, undefined, 1+breathe);
      aura=0.9;
    }
    const head=document.getElementById('scHead');
    if(head){const hx=parseFloat(head.getAttribute('cx')),hy=parseFloat(head.getAttribute('cy'));
      setCircle('scAura',hx,hy,aura>0?(28+aura*22):0);
      setText('scAura','stroke',`rgba(var(--cyan),${(aura*0.6).toFixed(2)})`);}

    // ════ GRATITUDE: eye glows, beam to person, thank you ════
    if(ph.name==='GRATITUDE'){
      const eyeT=eio(clamp(lt/0.45,0,1));
      setOpacity('a3Eye',eyeT);
      const halo=document.getElementById('a3EyeHalo');
      if(halo){const pulse=(Math.sin(now/700)+1)/2;halo.setAttribute('r',(20+pulse*10).toFixed(1));halo.setAttribute('opacity',(eyeT*(0.3+pulse*0.2)).toFixed(2));}
      const pupil=document.getElementById('a3EyePupil');
      if(pupil){const pl=(Math.sin(now/400)+1)/2;pupil.setAttribute('r',(3.5+pl*2).toFixed(1));}
      // gentle beam from eye down toward person
      const beam=document.getElementById('a3Beam');
      if(beam){const ba=eio(clamp((lt-0.3)/0.4,0,1))*(0.25+Math.sin(now/600)*0.08);
        beam.setAttribute('stroke',`rgba(var(--cyan),${Math.max(0,ba).toFixed(2)})`);
        beam.setAttribute('stroke-dashoffset',(-t*0.04).toFixed(1));}
      const thanksA=eio(clamp((lt-0.35)/0.4,0,1));
      setOpacity('a3Thanks',thanksA);
      setText('a3Thanks','fill',`rgba(var(--cyan),${(thanksA*0.9).toFixed(2)})`);
      setOpacity('a3Ring',0); setOpacity('a3Success',0); setOpacity('a3Stars',0);
      setCaption('before the climb — gratitude', true);
    } else { setOpacity('a3Eye',0); setOpacity('a3Thanks',0); setOpacity('a3Beam',0); }

    // ════ PUSH: energy core builds, progress ring fills in surges ════
    if(ph.name==='PUSH'){
      // core pulses & flickers (the effort / attempts that don't quite land)
      const core=document.getElementById('a3Core');
      if(core){
        const grow=eio(lt);
        const flicker=0.7+Math.sin(now/130)*0.15;
        const pulse=(Math.sin(now/300)+1)/2;
        core.setAttribute('r',(8+grow*16+pulse*3).toFixed(1));
        core.setAttribute('opacity',(grow*0.7*flicker).toFixed(2));
      }
      // progress ring fills in 4 surges (each surge = an attempt)
      const ring=document.getElementById('a3Ring');
      if(ring){
        const C=2*Math.PI*96;
        if(!ring._set){ring._set=1;ring.style.strokeDasharray=C;}
        // stepped progress with tiny dips between surges (persistence)
        const surges=4; const seg=lt*surges; const si=Math.floor(seg); const sf=seg-si;
        let prog=(si + eio(clamp(sf*1.25,0,1)))/surges;   // surge then small pause
        prog=clamp(prog,0,1);
        ring.style.strokeDashoffset=(C*(1-prog)).toFixed(1);
        ring.setAttribute('opacity',(0.4+prog*0.5).toFixed(2));
        ring.setAttribute('stroke',`rgba(var(--cyan),${(0.5+prog*0.45).toFixed(2)})`);
      }
      // a few particles swirl inward toward the core (gathering effort)
      swirlIn(true, now);
      setOpacity('a3Stars',0); setOpacity('a3Success',0);
      setCaption('every attempt, one step closer', false);
    } else { swirlIn(false, now); }

    // ════ BREAKTHROUGH: ring completes → burst of rays + flash ════
    if(ph.name==='BREAKTHROUGH'){
      // ring snaps to full then flares
      const ring=document.getElementById('a3Ring');
      if(ring){const C=2*Math.PI*96; ring.style.strokeDashoffset='0';
        const fade=Math.max(0,1-lt*1.4);
        ring.setAttribute('opacity',(fade*0.9).toFixed(2));
        ring.setAttribute('stroke',`rgba(var(--cyan),${(0.6+0.4*(Math.sin(now/120)+1)/2).toFixed(2)})`);}
      // core flares bright white
      const core=document.getElementById('a3Core');
      if(core){const fl=eio(clamp(lt/0.4,0,1));core.setAttribute('r',(24+fl*30).toFixed(1));core.setAttribute('opacity',(0.7+fl*0.3).toFixed(2));}
      // expanding burst ring
      const burst=document.getElementById('a3Burst');
      if(burst){const b=eio(lt);burst.setAttribute('r',(b*240).toFixed(1));burst.setAttribute('stroke',`rgba(var(--cyan),${(Math.max(0,(1-b))*0.7).toFixed(2)})`);burst.setAttribute('stroke-width',(3*(1-b)+0.5).toFixed(1));}
      // rays explode outward
      drawRays(eio(clamp((lt-0.2)/0.6,0,1)), now, 1);
      // burst particles
      risingLight(lt>0.2, CENTER_X, CENTER_Y, now);
      const mood=document.getElementById('scMoodGlow'); if(mood) mood.setAttribute('opacity',(0.6+eio(lt)*0.4).toFixed(2));
      setOpacity('a3Stars',0); setOpacity('a3Success',0);
      setCaption('breakthrough', true);
    }

    // ════ TRIUMPH: radiating light + ripples + stars + soaring particles ════
    if(ph.name==='TRIUMPH'){
      setOpacity('a3Ring',0);
      // core steady bright
      const core=document.getElementById('a3Core');
      if(core){const pulse=(Math.sin(now/600)+1)/2;core.setAttribute('r',(30+pulse*6).toFixed(1));core.setAttribute('opacity',(0.85+pulse*0.1).toFixed(2));}
      // rays radiate (full), slow rotation + pulse
      drawRays(1, now, 1);
      // expanding ripples (waves of success)
      ripples(now, lt);
      // burst ring keeps fading
      setOpacity('a3Burst',0);
      // stars fill the sky
      const sg=document.getElementById('a3Stars');
      if(sg){ if(!sg._b){sg._b=1;let hh='';for(let i=0;i<14;i++){hh+=`<circle cx="${(250+Math.random()*200).toFixed(0)}" cy="${(150+Math.random()*180).toFixed(0)}" r="${(0.6+Math.random()*1.3).toFixed(1)}" fill="rgba(220,235,255,0.9)"/>`;}sg.innerHTML=hh;}
        const sa=eio(clamp(lt/0.4,0,1)); sg.setAttribute('opacity',sa.toFixed(2));
        sg.querySelectorAll('circle').forEach((c,i)=>{const tw=(Math.sin(now/600+i*1.4)+1)/2;c.setAttribute('opacity',(sa*(0.4+tw*0.6)).toFixed(2));}); }
      // soaring particles
      risingLight(true, CENTER_X, CENTER_Y+10, now);
      // success statement
      const succA=eio(clamp((lt-0.3)/0.4,0,1));
      setOpacity('a3Success',succA);
      setText('a3Success','fill',`rgba(var(--ice),${(succA*0.92).toFixed(2)})`);
      const mood=document.getElementById('scMoodGlow'); if(mood) mood.setAttribute('opacity',(0.7+eio(lt)*0.5).toFixed(2));
      setCaption('the problem he carried — solved', true);
    } else {
      // clear rays/ripples when not triumphing (except breakthrough draws its own)
      if(ph.name!=='BREAKTHROUGH'){ const rg=document.getElementById('a3Rays'); if(rg)rg.innerHTML=''; }
      const rp=document.getElementById('a3Ripples'); if(rp && ph.name!=='TRIUMPH') rp.innerHTML='';
    }
  }

  // radiating rays from center (intensity 0-1)
  function drawRays(intensity, now, on){
    const rg=document.getElementById('a3Rays'); if(!rg) return;
    if(intensity<=0.01){ rg.innerHTML=''; return; }
    const N=18, inner=58, outer=58+intensity*150;
    const rot=now/4000;   // slow rotation
    let hh='';
    for(let i=0;i<N;i++){
      const ang=(i/N)*Math.PI*2+rot;
      const len=outer*(0.7+0.3*Math.sin(now/500+i));   // shimmering lengths
      const x1=CENTER_X+Math.cos(ang)*inner, y1=CENTER_Y+Math.sin(ang)*inner;
      const x2=CENTER_X+Math.cos(ang)*len,  y2=CENTER_Y+Math.sin(ang)*len;
      const a=(intensity*0.28*(0.6+0.4*Math.sin(now/500+i))).toFixed(3);
      hh+=`<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="rgba(var(--cyan),${a})" stroke-width="${(1.2+intensity).toFixed(1)}" stroke-linecap="round"/>`;
    }
    rg.innerHTML=hh;
  }

  // expanding concentric ripples (waves of success)
  function ripples(now, lt){
    const rp=document.getElementById('a3Ripples'); if(!rp) return;
    if(!rp._r) rp._r=[];
    const arr=rp._r;
    // spawn a ripple periodically
    if(!rp._last || now-rp._last>1100){ rp._last=now; arr.push({r:40, born:now}); }
    let hh='';
    for(let i=arr.length-1;i>=0;i--){
      const age=(now-arr[i].born)/2600;   // lifespan
      if(age>=1){ arr.splice(i,1); continue; }
      const r=40+age*180;
      const a=(0.3*(1-age)).toFixed(3);
      hh+=`<circle cx="${CENTER_X}" cy="${CENTER_Y}" r="${r.toFixed(1)}" fill="none" stroke="rgba(var(--cyan),${a})" stroke-width="${(1.6*(1-age)+0.4).toFixed(1)}"/>`;
    }
    rp.innerHTML=hh;
  }

  // particles swirling inward toward the core (effort gathering)
  function swirlIn(active, now){
    const rg=document.getElementById('scRising'); if(!rg) return;
    if(!rg._swirl) rg._swirl=[];
    const s=rg._swirl;
    if(active && Math.random()<0.35){
      const ang=Math.random()*Math.PI*2; const dist=120+Math.random()*60;
      s.push({ang, dist, sp:1.2+Math.random()*0.8, life:1});
    }
    // note: swirl particles render into a3Ripples-adjacent? keep simple: render in a3Rays-like overlay via scRising secondary
    // We piggyback render here directly:
    let extra='';
    for(let i=s.length-1;i>=0;i--){
      const p=s[i]; p.dist-=p.sp; p.life-=0.012;
      if(p.dist<=20||p.life<=0){ s.splice(i,1); continue; }
      const x=CENTER_X+Math.cos(p.ang)*p.dist, y=CENTER_Y+Math.sin(p.ang)*p.dist;
      const a=(p.life*0.5).toFixed(2);
      extra+=`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="1.6" fill="rgba(var(--cyan),${a})"/>`;
    }
    // render swirl into a dedicated layer (reuse a3Ripples if idle in PUSH)
    const rp=document.getElementById('a3Ripples'); if(rp) rp.innerHTML=extra;
  }

  function risingLight(active, cx, cy, now){
    const rg=document.getElementById('scRising'); if(!rg) return;
    if(!rg._parts) rg._parts=[];
    const parts=rg._parts;
    if(active && Math.random()<0.3) parts.push({x:cx+(Math.random()-0.5)*40,y:cy-Math.random()*30,vy:-(0.8+Math.random()*1.0),vx:(Math.random()-0.5)*0.3,life:1.0,r:1+Math.random()*1.5,phase:Math.random()*6});
    let hh='';
    for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.x+=p.vx+Math.sin(now/600+p.phase)*0.3;p.y+=p.vy;p.life-=0.01;if(p.life<=0){parts.splice(i,1);continue;}hh+=`<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="${p.r.toFixed(1)}" fill="rgba(var(--cyan),${(p.life*0.6).toFixed(2)})"/>`;}
    rg.innerHTML=hh;
  }

  let _lastCap='';
  function setCaption(txt, cyan){
    const cap=document.getElementById('scCaption'); if(!cap) return;
    if(_lastCap!==txt){ _lastCap=txt; cap.style.opacity='0';
      setTimeout(()=>{ if(cap){cap.textContent=txt;cap.style.opacity='1';cap.setAttribute('fill',cyan?'rgba(var(--cyan),0.7)':'rgba(var(--ice),0.55)');}},200);}
  }

  return {
    start(){ if(running)return; running=true; T=0; lastTime=0; smoke.length=0; _lastCap=''; lastSmoke=0;
      const rg=document.getElementById('scRising');
      if(rg){rg._parts=[];rg._mw=[];rg._swirl=[];}
      const rp=document.getElementById('a3Ripples'); if(rp){rp._r=[];}
      raf=requestAnimationFrame(frame); },
    stop(){ running=false; if(raf)cancelAnimationFrame(raf); smoke.length=0;
      const rg=document.getElementById('scRising');
      if(rg){rg._parts=[];rg._mw=[];rg._swirl=[];rg.innerHTML='';}
      const rp=document.getElementById('a3Ripples'); if(rp){rp._r=[];rp.innerHTML='';}
      const sg=document.getElementById('a2Smoke'); if(sg)sg.innerHTML='';
      // hide moonwalk extras
      ['scHat','scMoonBeam','scMoonPool','scMoonGlow','scMoonTrail'].forEach(id=>{
        const el=document.getElementById(id); if(el)el.setAttribute('opacity','0'); }); },
    restart(){ this.stop(); this.start(); }
  };
})();

const LJ = SCENE;
function restartScene(){ SCENE.restart(); }
function restartUntangle(){ SCENE.restart(); }
