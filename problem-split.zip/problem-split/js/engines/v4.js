const V4 = (function(){
  let _raf=null, _alive=false, _t0=0;
  let _loopCount=0;            // counts full loops — text varies each time
  let _tapFlash=0;             // timestamp of last tap — drives reaction
  let _tapX=0, _tapY=0;       // tap position for ripple
  let _eyeTrackX=0, _eyeTrackY=0; // character pupil target (follows maze eye)
  let _prevLoopCount=-1;       // detects new loop → reset flash
  const TOTAL=30000;

  // ── Problem words (Gen Z emotional vocabulary) ──────────
  // Seeing their own words floating = emotional recognition = they STAY
  const WORD_SETS=[
    ['overthinking','what if','not enough','comparing','lost'],
    ['too much','can\'t decide','what\'s wrong with me','stuck','why'],
    ['replaying it','spiraling','behind','tired','invisible'],
  ];
  // Stable orbit positions for the words
  const WORD_ORBITS=Array.from({length:5},(_,i)=>({
    angle: i*72*Math.PI/180 + i*0.2,
    r:     0.55 + (i%3)*0.15,
    spin:  (i%2?1:-1)*(0.12+i*0.02),
    size:  0.022+i%3*0.004,
  }));

  // ── Text variants (new phrase each loop) ──────────────
  const TEXT_VARIANTS=[
    ['sometimes it gets loud up there','we see what you\'re carrying','there\'s always a way through'],
    ['your maze is real — so is the exit','you\'re not the only one here','one step is enough'],
    ['it\'s okay to not have it figured out','someone sees the whole picture','clarity is closer than you think'],
    ['you\'ve been carrying this alone','we see the full maze','the path was always there'],
  ];

  // ─ helpers ─────────────────────────────────────────────
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const lerp=(a,b,t)=>a+(b-a)*t;
  const eio=t=>t<0.5?2*t*t:1-Math.pow(-2*t+2,2)/2;
  const pp=(t,s,e)=>clamp((t-s)/(e-s),0,1); // phase progress

  // ─ fragment field (stable random seed) ─────────────────
  const FRAGS=Array.from({length:18},(_,i)=>{
    const a=i*137.508*Math.PI/180, r=55+i*14;
    return { bx:Math.cos(a)*r, by:Math.sin(a)*r,
             size:8+i%5*4, spin:i%2?1:-1, phase:i*0.4 };
  });

  // ─ draw one mini maze fragment ──────────────────────────
  function drawFrag(ctx,x,y,s,rot,alpha){
    ctx.save();ctx.translate(x,y);ctx.rotate(rot);ctx.globalAlpha=alpha;
    ctx.strokeStyle='rgba(225,235,248,0.85)';
    [s,s*.75,s*.5].forEach(r=>{
      ctx.lineWidth=0.8;ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.stroke();
    });
    ctx.lineWidth=0.7;
    [[0,-s,0,-s*.75],[s,0,s*.75,0],[-s*.5,0,-s*.75,0]].forEach(([x1,y1,x2,y2])=>{
      ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();
    });
    // tiny solve dot
    ctx.fillStyle='rgba(232,242,255,0.9)';ctx.beginPath();ctx.arc(0,0,1.5,0,Math.PI*2);ctx.fill();
    ctx.restore();
  }

  // ─ draw the central maze eye ────────────────────────────
  function drawEye(ctx,cx,cy,sc,now,pSolve){
    const ICE='rgba(225,235,248,', CY='rgba(232,242,255,';
    const rot=now*0.12;

    // aura
    const ag=ctx.createRadialGradient(cx,cy,0,cx,cy,sc*1.4);
    ag.addColorStop(0,`rgba(100,160,255,0.12)`);ag.addColorStop(1,'rgba(100,160,255,0)');
    ctx.fillStyle=ag;ctx.beginPath();ctx.arc(cx,cy,sc*1.4,0,Math.PI*2);ctx.fill();

    // lid glow
    ctx.save();ctx.filter='blur(8px)';
    ctx.strokeStyle=`rgba(232,242,255,0.12)`;ctx.lineWidth=12;
    ctx.beginPath();ctx.moveTo(cx-sc,cy);ctx.quadraticCurveTo(cx,cy-sc*.7,cx+sc,cy);ctx.stroke();
    ctx.restore();

    // upper lid
    const ug=ctx.createLinearGradient(cx-sc,0,cx+sc,0);
    ug.addColorStop(0,ICE+'0.2)');ug.addColorStop(.5,CY+'1)');ug.addColorStop(1,ICE+'0.2)');
    ctx.strokeStyle=ug;ctx.lineWidth=2.5;ctx.lineCap='round';
    ctx.beginPath();ctx.moveTo(cx-sc,cy);ctx.quadraticCurveTo(cx,cy-sc*.7,cx+sc,cy);ctx.stroke();
    // lower lid
    ctx.strokeStyle=`rgba(225,235,248,0.55)`;ctx.lineWidth=2;
    ctx.beginPath();ctx.moveTo(cx-sc,cy);ctx.quadraticCurveTo(cx,cy+sc*.45,cx+sc,cy);ctx.stroke();

    // rings (rotating)
    ctx.save();ctx.translate(cx,cy);ctx.rotate(rot);
    [sc*.8,sc*.63,sc*.47,sc*.33,sc*.2].forEach((r,i)=>{
      ctx.strokeStyle=`rgba(225,235,248,${[.5,.4,.32,.25,.2][i]})`;
      ctx.lineWidth=[1.5,1.3,1.2,1,.9][i];
      ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.stroke();
    });
    // walls
    [[0,-sc*.8,0,-sc*.63],[sc*.63,0,sc*.47,0],[-sc*.47,0,-sc*.63,0]].forEach(([x1,y1,x2,y2])=>{
      ctx.strokeStyle='rgba(225,235,248,0.25)';ctx.lineWidth=0.9;
      ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();
    });
    ctx.restore();

    // solve path
    if(pSolve>0){
      const pts=[];const turns=2.1,steps=60;
      for(let k=0;k<=steps;k++){
        const u=k/steps,ang=-Math.PI/2+u*Math.PI*2*turns,rad=lerp(sc*.8,5,1-Math.pow(1-u,3));
        pts.push([cx+Math.cos(ang)*rad,cy+Math.sin(ang)*rad]);
      }
      const N=Math.floor(pts.length*(1-Math.pow(1-pSolve,3)));
      ctx.save();ctx.strokeStyle='rgba(232,242,255,0.92)';ctx.lineWidth=2.2;
      ctx.lineCap='round';ctx.lineJoin='round';
      ctx.shadowColor='rgba(232,242,255,0.9)';ctx.shadowBlur=9;
      ctx.beginPath();for(let k=0;k<N;k++){const[px,py]=pts[k];k?ctx.lineTo(px,py):ctx.moveTo(px,py);}
      ctx.stroke();ctx.shadowBlur=0;ctx.restore();
    }

    // pupil
    const pr=sc*.14;
    ctx.save();ctx.shadowColor='rgba(232,242,255,1)';ctx.shadowBlur=14;
    ctx.fillStyle='rgba(232,242,255,0.95)';ctx.beginPath();ctx.arc(cx,cy,pr,0,Math.PI*2);ctx.fill();
    ctx.restore();
    ctx.fillStyle='rgba(4,6,8,0.95)';ctx.beginPath();ctx.arc(cx,cy,pr*.35,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='rgba(255,255,255,0.8)';ctx.beginPath();ctx.arc(cx+pr*.4,cy-pr*.4,pr*.3,0,Math.PI*2);ctx.fill();

    // orbit dot
    const oa=now*1.3,or=sc*.5;
    ctx.save();ctx.shadowColor='rgba(232,242,255,0.9)';ctx.shadowBlur=7;
    ctx.fillStyle='rgba(232,242,255,0.85)';
    ctx.beginPath();ctx.arc(cx+Math.cos(oa)*or,cy+Math.sin(oa)*or*.66,2.2,0,Math.PI*2);ctx.fill();
    ctx.restore();
  }

  // ─ draw the anime character ─────────────────────────────
  function drawChar(ctx,cx,cy,sc,now,slump,smile,eyeOffX,eyeOffY,breath){
    const I='rgba(225,235,248,', C='rgba(232,242,255,', S=sc;
    const eox=eyeOffX||0, eoy=eyeOffY||0;
    const br=(breath||0)*S*.018;  // breathing offset for torso
    const f=Math.sin(now*1.5)*3; // float

    ctx.save(); ctx.translate(0,f);

    // Anime proportions: head ~38% of total height
    // anchor: cy = vertical center of character
    const hx=cx, hy=cy-S*.26+slump*S*.12; // head center
    const hr=S*.26;  // head radius
    const by=hy+hr+S*.04; // body top

    // ── BACK HAIR ──
    ctx.strokeStyle=I+'0.52)'; ctx.lineWidth=S*.022; ctx.lineCap='round';
    [[-0.22,-0.35,-0.30,-0.68],[-0.14,-0.37,-0.20,-0.72]].forEach(([x1,y1,x2,y2])=>{
      ctx.beginPath(); ctx.moveTo(hx+x1*S,hy+y1*S);
      ctx.quadraticCurveTo(hx+x2*S-0.02*S,hy+y2*S,hx+x2*S,hy+y2*S-0.08*S);
      ctx.stroke();
    });

    // ── HEAD (anime oval — slightly wider than tall) ──
    ctx.save();
    ctx.strokeStyle=I+'0.88)'; ctx.lineWidth=S*.020; ctx.lineCap='round';
    ctx.beginPath();
    ctx.ellipse(hx, hy, hr*.88, hr, 0, 0, Math.PI*2);
    ctx.fillStyle='rgba(4,6,8,0.8)'; ctx.fill(); ctx.stroke();
    ctx.restore();

    // ── FRONT HAIR / BANGS ──
    ctx.strokeStyle=I+'0.72)'; ctx.lineWidth=S*.024; ctx.lineCap='round';
    // three main bangs
    [[-0.18,-0.85],[-0.08,-0.88],[0.04,-0.86]].forEach(([bx,by2],i)=>{
      ctx.beginPath();
      ctx.moveTo(hx+[-0.30,-0.15,0.10][i]*S, hy-hr*.5);
      ctx.quadraticCurveTo(hx+bx*S*1.1,hy+by2*hr,hx+bx*S,hy+by2*hr+0.05*S);
      ctx.stroke();
    });
    // hair top sweep
    ctx.strokeStyle=I+'0.55)'; ctx.lineWidth=S*.018;
    ctx.beginPath();
    ctx.moveTo(hx-hr*.82,hy-hr*.4);
    ctx.quadraticCurveTo(hx-hr*.2,hy-hr*1.12,hx+hr*.6,hy-hr*.95);
    ctx.stroke();

    // ── ANIME EYES (proper almond — filled dark with iris inside) ──
    const eyeY = hy - hr*.08;
    const eyeW = hr*.55, eyeH = hr*.38;
    [-0.30, 0.30].forEach((ex, ei) => {
      const ecx = hx + ex*S;
      const blink = 0.8+Math.sin(now*2.1+ei*1.3)*0.12;
      const eh = eyeH*blink;

      // shadow glow
      ctx.save();
      ctx.filter = 'blur(4px)';
      ctx.fillStyle = C+'0.08)';
      ctx.beginPath(); ctx.ellipse(ecx,eyeY,eyeW*1.3,eh*1.5,0,0,Math.PI*2);
      ctx.fill(); ctx.restore();

      // ── eye shape: close the full almond ──
      ctx.save();
      ctx.beginPath();
      // upper lid (arches up)
      ctx.moveTo(ecx-eyeW, eyeY);
      ctx.quadraticCurveTo(ecx, eyeY-eh*1.5, ecx+eyeW, eyeY);
      // lower lid (gentle curve down)
      ctx.quadraticCurveTo(ecx, eyeY+eh*.8, ecx-eyeW, eyeY);
      ctx.closePath();
      ctx.fillStyle='rgba(4,6,8,0.88)'; ctx.fill();
      // upper lid stroke (thicker, defining)
      ctx.beginPath();
      ctx.moveTo(ecx-eyeW, eyeY);
      ctx.quadraticCurveTo(ecx, eyeY-eh*1.5, ecx+eyeW, eyeY);
      ctx.strokeStyle=I+'0.92)'; ctx.lineWidth=S*.022; ctx.stroke();
      // lower lid stroke (thinner)
      ctx.beginPath();
      ctx.moveTo(ecx-eyeW,eyeY);
      ctx.quadraticCurveTo(ecx,eyeY+eh*.8,ecx+eyeW,eyeY);
      ctx.strokeStyle=I+'0.45)'; ctx.lineWidth=S*.012; ctx.stroke();
      ctx.restore();

      // ── iris — maze rings inside (mini labyrinth) ──
      const ir = eyeH*.85;
      ctx.save();
      [ir, ir*.7, ir*.45].forEach((r,ri)=>{
        ctx.strokeStyle=I+[0.38,0.28,0.20][ri]+')';
        ctx.lineWidth=S*.009;
        ctx.beginPath(); ctx.arc(ecx,eyeY,r,0,Math.PI*2); ctx.stroke();
      });
      ctx.restore();

      // ── pupil: glowing ice dot (offset toward maze eye) ──
      ctx.save();
      ctx.shadowColor=C+'0.9)'; ctx.shadowBlur=S*.08;
      ctx.fillStyle=C+'0.95)';
      ctx.beginPath(); ctx.arc(ecx+eox,eyeY+eoy,ir*.38,0,Math.PI*2); ctx.fill();
      ctx.shadowBlur=0; ctx.restore();

      // ── highlight: anime sparkle (top-right) ──
      ctx.fillStyle='rgba(255,255,255,0.85)';
      ctx.beginPath(); ctx.ellipse(ecx+eyeW*.28,eyeY-eh*.6,ir*.24,ir*.16,-0.4,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='rgba(255,255,255,0.45)';
      ctx.beginPath(); ctx.ellipse(ecx-eyeW*.2,eyeY-eh*.75,ir*.12,ir*.09,0.2,0,Math.PI*2); ctx.fill();
    });

    // ── NOSE (tiny, subtle) ──
    ctx.strokeStyle=I+'0.22)'; ctx.lineWidth=S*.012; ctx.lineCap='round';
    ctx.beginPath();
    ctx.moveTo(hx-S*.02,eyeY+hr*.35);
    ctx.quadraticCurveTo(hx-S*.04,eyeY+hr*.44,hx+S*.05,eyeY+hr*.44);
    ctx.stroke();

    // ── MOUTH ──
    const sm = lerp(-S*.02, S*.06, smile);
    ctx.strokeStyle=I+'0.52)'; ctx.lineWidth=S*.016; ctx.lineCap='round';
    ctx.beginPath();
    ctx.moveTo(hx-S*.10, eyeY+hr*.58);
    ctx.quadraticCurveTo(hx, eyeY+hr*.62+sm, hx+S*.10, eyeY+hr*.58);
    ctx.stroke();

    // ── NECK + SHOULDERS + TORSO (breathing: br shifts torso up/down) ──
    ctx.strokeStyle=I+'0.65)'; ctx.lineWidth=S*.020; ctx.lineCap='round';
    // neck
    ctx.beginPath(); ctx.moveTo(hx-S*.06,hy+hr*.82); ctx.lineTo(hx-S*.05,by+br); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(hx+S*.06,hy+hr*.82); ctx.lineTo(hx+S*.05,by+br); ctx.stroke();
    // shoulders arc (slight breathing lift)
    ctx.beginPath();
    ctx.moveTo(hx-S*.38,by+S*.14+br);
    ctx.quadraticCurveTo(hx,by+br,hx+S*.38,by+S*.14+br);
    ctx.stroke();
    // torso (breathing: bottom expands slightly)
    ctx.beginPath();
    ctx.moveTo(hx-S*.28,by+S*.14+br); ctx.lineTo(hx-S*.24,by+S*.58-br*.3);
    ctx.lineTo(hx+S*.24,by+S*.58-br*.3); ctx.lineTo(hx+S*.28,by+S*.14+br);
    ctx.stroke();

    // ── LEFT ARM (raises as slump fades) ──
    const armRaise=clamp(1-slump*1.8,0,1);
    ctx.strokeStyle=I+'0.65)'; ctx.lineWidth=S*.019; ctx.lineCap='round';
    ctx.beginPath();
    ctx.moveTo(hx-S*.28,by+S*.14);
    ctx.quadraticCurveTo(
      hx-S*.50, by+lerp(S*.28,-S*.12,armRaise),
      hx-S*.56+armRaise*S*.12, by+lerp(S*.48,-S*.28,armRaise)
    );
    ctx.stroke();

    // ── RIGHT ARM (relaxed down) ──
    ctx.strokeStyle=I+'0.58)'; ctx.lineWidth=S*.019;
    ctx.beginPath();
    ctx.moveTo(hx+S*.28,by+S*.14);
    ctx.quadraticCurveTo(hx+S*.44,by+S*.36,hx+S*.46,by+S*.52);
    ctx.stroke();

    // ── LEGS ──
    ctx.strokeStyle=I+'0.58)'; ctx.lineWidth=S*.018; ctx.lineCap='round';
    ctx.beginPath(); ctx.moveTo(hx-S*.12,by+S*.58); ctx.lineTo(hx-S*.13,by+S*.96); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(hx+S*.12,by+S*.58); ctx.lineTo(hx+S*.13,by+S*.96); ctx.stroke();
    // shoes
    ctx.strokeStyle=I+'0.48)'; ctx.lineWidth=S*.014;
    [[-0.13,0.96,-0.22,0.99],[0.13,0.96,0.22,0.99]].forEach(([x1,y1,x2,y2])=>{
      ctx.beginPath(); ctx.moveTo(hx+x1*S,by+y1*S); ctx.lineTo(hx+x2*S,by+y2*S); ctx.stroke();
    });

    ctx.restore();
  }

  // ─ draw story text ──────────────────────────────────────
  function drawText(ctx,W,H,now,pOvr,pSolve,pClarity,pHold,txv){
    const T=txv||TEXT_VARIANTS[0];
    ctx.textAlign='center';
    if(pOvr>0.3&&pOvr<0.95){
      const a=eio(clamp((pOvr-0.3)/0.3,0,1))*eio(clamp((0.95-pOvr)/0.2,0,1));
      ctx.globalAlpha=a*0.75;ctx.font=`300 ${W*.030}px 'Sora',sans-serif`;
      ctx.fillStyle='rgba(225,235,248,1)';ctx.fillText(T[0],W/2,H*.22);ctx.globalAlpha=1;
    }
    if(pSolve>0.35&&pSolve<0.92){
      const a=eio(clamp((pSolve-0.35)/0.3,0,1))*eio(clamp((0.92-pSolve)/0.2,0,1));
      ctx.globalAlpha=a*0.82;ctx.font=`300 ${W*.032}px 'Sora',sans-serif`;
      ctx.fillStyle='rgba(232,242,255,1)';ctx.fillText(T[1],W/2,H*.22);ctx.globalAlpha=1;
    }
    if(pClarity>0.4){
      const a=eio(clamp((pClarity-0.4)/0.35,0,1));
      ctx.globalAlpha=a*0.9;ctx.font=`300 ${W*.034}px 'Sora',sans-serif`;
      ctx.fillStyle='rgba(232,242,255,1)';
      ctx.shadowColor='rgba(232,242,255,0.4)';ctx.shadowBlur=14;
      ctx.fillText(T[2],W/2,H*.22);ctx.shadowBlur=0;ctx.globalAlpha=1;
    }
    if(pHold>0.3){
      const a=eio(clamp((pHold-0.3)/0.4,0,1));
      ctx.globalAlpha=a*0.3;ctx.font=`300 ${W*.016}px 'DM Mono',monospace`;
      ctx.fillStyle='rgba(225,235,248,1)';ctx.fillText('PROBLEM — THE MAZE EYE',W/2,H*.92);
      ctx.globalAlpha=1;
    }
  }

  // ─ floating problem words ───────────────────────────────
  function drawWords(ctx,cx,cy,sc,now,pEmerge,pOvr,pEye,pClarity){
    const words=WORD_SETS[_loopCount%WORD_SETS.length];
    const appear=eio(Math.min(pEmerge*1.8+pOvr*0.6,1));
    const dissolve=eio(clamp((pEye-0.3)/0.5,0,1));
    const alpha=appear*(1-dissolve*0.92);
    if(alpha<0.01) return;
    ctx.save();
    WORD_ORBITS.forEach((orb,i)=>{
      if(i>=words.length) return;
      // ── VORTEX: pOvr > 0.6 → words spiral inward ──
      const vortex=eio(clamp((pOvr-0.6)/0.4,0,1));
      const angBoost=1+vortex*5;  // spins faster as vortex increases
      const a=orb.angle+now*orb.spin*angBoost;
      const spread=lerp(0.2,1,eio(Math.min(pEmerge*1.8+pOvr*0.3,1)));
      const baseR=sc*orb.r*spread;
      // Shrink radius toward head center (vortex pull)
      const r=baseR*(1-vortex*.88);
      const wx=cx+Math.cos(a)*r, wy=(cy-sc*.18)+Math.sin(a)*r*0.55;
      // Words scale down and fade at vortex peak
      const wordScale=lerp(1,0.4,vortex);
      const vortexFade=vortex>0.85?eio(1-(vortex-0.85)/0.15):1;
      const appear=eio(Math.min(pEmerge*1.8+pOvr*0.6,1));
      const dissolve=eio(clamp((pEye-0.3)/0.5,0,1));
      const alpha=appear*(1-dissolve*0.92)*vortexFade;
      ctx.globalAlpha=Math.max(0,alpha*(0.38+Math.sin(now*0.8+i*1.3)*0.14));
      ctx.font=`300 ${sc*orb.size*wordScale}px 'DM Mono',monospace`;
      ctx.fillStyle='rgba(225,235,248,1)';ctx.textAlign='center';
      ctx.fillText(words[i],wx,wy);
      // clarity: word shrinks to a glowing dot
      if(pClarity>0.2){
        const dp=eio(clamp((pClarity-0.2)/0.5,0,1));
        ctx.globalAlpha=dp*0.5;
        ctx.fillStyle='rgba(232,242,255,0.9)';
        ctx.shadowColor='rgba(232,242,255,0.7)';ctx.shadowBlur=sc*.06;
        ctx.beginPath();ctx.arc(wx,wy,sc*.014,0,Math.PI*2);ctx.fill();
        ctx.shadowBlur=0;
      }
    });
    ctx.restore();
  }

  // ─ tap ripple ────────────────────────────────────────────
  function drawTapRipple(ctx,now){
    if(!_tapFlash) return;
    const age=(now*1000-_tapFlash)/1000;
    if(age>1.2) return;
    const r=age*120;
    ctx.save();
    ctx.strokeStyle=`rgba(232,242,255,${Math.max(0,0.5*(1-age/1.2))})`;
    ctx.lineWidth=1.5;
    ctx.beginPath();ctx.arc(_tapX,_tapY,r,0,Math.PI*2);ctx.stroke();
    ctx.restore();
  }

  // ─ "being seen" heart beam ───────────────────────────────
  function drawHeartBeam(ctx,charX,charY,sc,eyeX,eyeY,pSolve){
    if(pSolve<0.08) return;
    const a=eio(clamp((pSolve-0.08)/0.6,0,1));
    const now=performance.now()/1000;
    const cX=charX, cY=charY+sc*.16;
    ctx.save();
    for(let i=0;i<18;i++){
      const u=i/17;
      const px=lerp(cX,eyeX,u)+Math.sin(u*Math.PI)*sc*.07*Math.sin(now*1.2);
      const py=lerp(cY,eyeY,u);
      const pa=a*Math.sin(u*Math.PI)*0.65;
      ctx.globalAlpha=Math.max(0,pa);
      ctx.fillStyle='rgba(232,242,255,0.85)';
      ctx.shadowColor='rgba(232,242,255,0.8)';ctx.shadowBlur=sc*.04;
      ctx.beginPath();ctx.arc(px,py,sc*.013*(1-u*.4),0,Math.PI*2);ctx.fill();
      ctx.shadowBlur=0;
    }
    ctx.restore();
  }

  // ═══ DEVELOPMENT 1: EYE FLASH ════════════════════════════
  // Brief cinematic flash when the maze eye first materialises.
  // pFlash = pp(t, 11000, 11800) — 800ms window at eye birth.
  function drawEyeFlash(ctx,ex,ey,sc,pFlash){
    if(pFlash<=0||pFlash>=1) return;
    // Outer expanding ring
    const r=sc*.25+pFlash*sc*1.4;
    const a=Math.sin(pFlash*Math.PI)*0.7;
    ctx.save();
    ctx.strokeStyle=`rgba(232,242,255,${a})`;
    ctx.lineWidth=2.5;
    ctx.shadowColor='rgba(232,242,255,0.9)';ctx.shadowBlur=sc*.15;
    ctx.beginPath();ctx.arc(ex,ey,r,0,Math.PI*2);ctx.stroke();
    ctx.shadowBlur=0;
    // Inner fill flash
    const fa=Math.sin(pFlash*Math.PI)*0.15;
    const gr=ctx.createRadialGradient(ex,ey,0,ex,ey,sc*.5);
    gr.addColorStop(0,`rgba(232,242,255,${fa})`);
    gr.addColorStop(1,'rgba(232,242,255,0)');
    ctx.fillStyle=gr;ctx.beginPath();ctx.arc(ex,ey,sc*.5,0,Math.PI*2);ctx.fill();
    ctx.restore();
  }

  // ═══ DEVELOPMENT 2: RISING PARTICLES (CLARITY) ═══════════
  // Particles rise UPWARD = liberation / hope metaphor.
  // Much more emotionally correct than circular orbit.
  function drawRising(ctx,cx,cy,sc,now,pClarity,pHold){
    if(pClarity<=0) return;
    const progress=eio(pClarity);
    const fade=1-eio(pHold*.8);
    for(let i=0;i<28;i++){
      const seed=i*1.618;
      // Spread source points across body area
      const srcX=cx+(((i*7)%13)-6)*sc*.06;
      const srcY=cy+sc*.1+((i%4)-2)*sc*.08;
      // Each particle rises at its own rate, slight horizontal drift
      const riseRate=0.4+i%5*.12;
      const rise=progress*sc*1.5*riseRate;
      const sway=Math.sin(now*0.7+i*0.8)*sc*.05;
      const px=srcX+sway;
      const py=srcY-rise;
      // Fade: in at start, out before pHold
      const pa=eio(Math.min(pClarity*3,1))*fade*(0.55+i%3*.12);
      if(pa<0.02||py<-20) continue;
      const r=1.2+i%4*.5;
      ctx.save();
      ctx.globalAlpha=Math.max(0,pa);
      ctx.fillStyle='rgba(232,242,255,0.95)';
      ctx.shadowColor='rgba(232,242,255,0.8)';ctx.shadowBlur=r*3;
      ctx.beginPath();ctx.arc(px,py,r,0,Math.PI*2);ctx.fill();
      ctx.shadowBlur=0;ctx.restore();
    }
  }

  // ═══ DEVELOPMENT 3: THOUGHT BUBBLE (INTRO) ═══════════════
  // Before the maze fragments appear, a "?" floats above the head.
  // "I have something I can't figure out alone."
  function drawThought(ctx,cx,cy,sc,pIntro,pEmerge){
    const show=eio(pIntro)*(1-eio(pEmerge*2.5)); // fades as emerge starts
    if(show<0.02) return;
    const hx=cx-sc*.08, hy=cy-sc*.62;            // above head
    ctx.save();ctx.globalAlpha=show;
    // Small trail dots
    [[0,sc*.08],[sc*.04,sc*.16],[sc*.02,sc*.24]].forEach(([dx,dy],i)=>{
      const r=3.5-i*.8;
      ctx.fillStyle=`rgba(225,235,248,${0.5-i*.1})`;
      ctx.beginPath();ctx.arc(hx+dx,hy+dy,r,0,Math.PI*2);ctx.fill();
    });
    // Bubble
    ctx.strokeStyle='rgba(225,235,248,0.7)';ctx.lineWidth=1.6;
    ctx.fillStyle='rgba(4,6,8,0.55)';
    ctx.beginPath();ctx.ellipse(hx,hy-sc*.06,sc*.08,sc*.06,0,0,Math.PI*2);
    ctx.fill();ctx.stroke();
    // "?" mark
    ctx.fillStyle='rgba(232,242,255,0.9)';
    ctx.font=`600 ${sc*.07}px 'Sora',sans-serif`;
    ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillText('?',hx,hy-sc*.06);
    ctx.textBaseline='alphabetic';
    ctx.restore();
  }

  // ═══ DEVELOPMENT 4: VORTEX — words spiral INTO head ══════
  // Already inside drawWords — modifies orbit calculation.
  // Separate draw pass for the vortex glow at peak overwhelm.
  function drawVortexCore(ctx,cx,cy,sc,now,pOvr){
    const vStrength=eio(clamp((pOvr-0.7)/0.3,0,1)); // 0→1 at pOvr 0.7..1.0
    if(vStrength<0.02) return;
    // Suction glow at head center
    const hx=cx, hy=cy-sc*.26;
    const gr=ctx.createRadialGradient(hx,hy,0,hx,hy,sc*.35*vStrength);
    gr.addColorStop(0,`rgba(100,140,255,${vStrength*.18})`);
    gr.addColorStop(1,'rgba(100,140,255,0)');
    ctx.save();ctx.fillStyle=gr;ctx.globalAlpha=vStrength;
    ctx.beginPath();ctx.arc(hx,hy,sc*.35,0,Math.PI*2);ctx.fill();
    ctx.restore();
  }

  // ─ main draw ────────────────────────────────────────────
  function draw(ctx,W,H,t){
    ctx.clearRect(0,0,W,H);
    const now=performance.now()/1000;
    const cx=W/2, cy=H*.44;
    const sc=Math.min(W,H)*0.27;

    // Count loops for text variation — tracked in loop(), not here

    const pIntro=pp(t,0,2500);
    const pEmerge=pp(t,2500,7000);
    const pOvr=pp(t,7000,11000);
    const pEye=pp(t,11000,16000);
    const pSolve=pp(t,16000,21000);
    const pClarity=pp(t,21000,26000);
    const pHold=pp(t,26000,30000);

    const charAlpha=eio(pIntro);
    const slump=eio(pOvr)*(1-eio(pEye)*.95)*(1-pClarity*.9);
    const smile=eio(pClarity)*eio(pHold*.5+.5);

    // ── DEV3: BREATHING — rate varies by phase ──
    const breathRate = pOvr>0 ? lerp(1.2, 2.2, eio(pOvr)) :
                       pClarity>0 ? lerp(1.2, 0.5, eio(pClarity)) : 1.2;
    const breathVal = Math.sin(performance.now()/1000 * breathRate);

    // ── tap flash: character pulse when tapped ──
    const tapAge=_tapFlash?(now*1000-_tapFlash)/1000:99;
    const tapPulse=tapAge<0.5?Math.sin(tapAge*Math.PI/0.5)*0.4:0;

    // ── eye tracking: pupil drifts toward maze eye ──
    const mazeEyeX=cx+W*.26, mazeEyeY=cy-sc*.62;
    const charCX=cx, charCY=cy+sc*.08;
    // lerp pupil toward maze eye when it appears
    const trackStrength=eio(pEye)*(1-pHold*.5);
    const dx=mazeEyeX-charCX, dy=mazeEyeY-charCY;
    const dist=Math.hypot(dx,dy)||1;
    _eyeTrackX=lerp(_eyeTrackX,dx/dist*sc*.06*trackStrength, 0.04);
    _eyeTrackY=lerp(_eyeTrackY,dy/dist*sc*.04*trackStrength, 0.04);

    // bg aura (brighter when tapped)
    const gr=ctx.createRadialGradient(cx,cy,0,cx,cy,sc*1.2);
    const aura=(pEye>0?0.07*eio(pEye):0)+(pClarity>0?0.06*eio(pClarity):0)+tapPulse*.06;
    gr.addColorStop(0,`rgba(100,160,255,${0.04+aura})`);
    gr.addColorStop(1,'rgba(100,160,255,0)');
    ctx.fillStyle=gr;ctx.beginPath();ctx.arc(cx,cy,sc*1.2,0,Math.PI*2);ctx.fill();

    // maze fragments
    const fAlpha=eio(pEmerge)*(1-eio(pEye)*0.85)*(1-pClarity);
    if(fAlpha>0.01){
      FRAGS.forEach((fr,i)=>{
        const q=Math.sin(now*.6+fr.phase);
        const spread=lerp(0.2,1,eio(pEmerge));
        const x=cx+fr.bx*sc*.55*spread+q*8;
        const y=cy+fr.by*sc*.4*spread+Math.cos(now*.5+fr.phase)*6;
        drawFrag(ctx,x,y,fr.size*sc/200,now*fr.spin*.3+fr.phase,
                 Math.max(0,fAlpha*(0.4+Math.sin(now+fr.phase)*0.2)*(i<12?1:0.6)));
      });
    }

    // ── DEV1: THOUGHT BUBBLE (INTRO) ──
    drawThought(ctx,cx,cy+sc*.08,sc,pIntro,pEmerge);

    // ── FLOATING PROBLEM WORDS (with vortex inside) ──
    drawWords(ctx,cx,cy+sc*.08,sc,now,pEmerge,pOvr,pEye,pClarity);

    // ── DEV4: VORTEX CORE GLOW at peak overwhelm ──
    drawVortexCore(ctx,cx,cy+sc*.08,sc,now,pOvr);

    // character (with breathing + eye tracking)
    if(charAlpha>0.01){
      ctx.save();ctx.globalAlpha=charAlpha*(1+tapPulse*.2);
      drawChar(ctx,cx,cy+sc*.08,sc,now,slump,smile,_eyeTrackX,_eyeTrackY,breathVal);
      ctx.restore();
    }

    // tap ripple
    drawTapRipple(ctx,now);

    // hand beam (dashed line)
    if(pEye>0.2&&pClarity<0.8){
      const ba=eio(clamp(pEye-0.2,0,1)/0.8)*(1-pClarity);
      const handX=cx-sc*.56, handY=cy-sc*.04;
      ctx.save();ctx.globalAlpha=ba*.3;
      ctx.strokeStyle='rgba(232,242,255,0.8)';ctx.lineWidth=1.2;
      ctx.setLineDash([5,8]);ctx.beginPath();
      ctx.moveTo(handX,handY);ctx.lineTo(mazeEyeX,mazeEyeY);ctx.stroke();
      ctx.setLineDash([]);ctx.restore();
    }

    // ── HEART BEAM (chest → maze eye during SOLVE) ──
    if(pSolve>0&&pClarity<0.9){
      drawHeartBeam(ctx,charCX,charCY,sc,mazeEyeX,mazeEyeY,pSolve);
    }

    // maze eye
    if(pEye>0){
      const ea=eio(pEye)*(1-pHold);
      ctx.save();ctx.globalAlpha=ea*(1+tapPulse*.3);
      drawEye(ctx,mazeEyeX,mazeEyeY,sc*.42,now,eio(pp(t,16000,21000)));
      ctx.restore();
    }

    // ── DEV1: EYE FLASH at birth ──
    drawEyeFlash(ctx,mazeEyeX,mazeEyeY,sc,pp(t,11000,11800));

    // ── DEV2: RISING PARTICLES (replaces circular orbit) ──
    drawRising(ctx,cx,cy+sc*.08,sc,now,pClarity,pHold);

    // ── LOOP-VARIED TEXT ──
    const txv=TEXT_VARIANTS[_loopCount%TEXT_VARIANTS.length];
    drawText(ctx,W,H,now,pOvr,pp(t,16000,21000),pClarity,pHold,txv);
  }

  // ─ loop ─────────────────────────────────────────────────
  let _lastDraw4=0;
  function loop(ts){
    if(!_alive)return;
    _raf=requestAnimationFrame(loop);
    const gap=perfFrameGap();
    if(gap&&ts-_lastDraw4<gap) return;
    _lastDraw4=ts;
    const cv=document.getElementById('heroV4Canvas');
    if(!cv)return;
    const rawT = ts - _t0;           // raw elapsed — for loop counting
    const t = rawT % TOTAL;
    const loopN = Math.floor(rawT / TOTAL);
    if(loopN > _loopCount) _loopCount = loopN;
    const r=cv.getBoundingClientRect();
    const dpr=perfDPR();
    const bw=Math.round(r.width*dpr),bh=Math.round(r.height*dpr);
    if(cv.width!==bw||cv.height!==bh){cv.width=bw;cv.height=bh;}
    const ctx=cv.getContext('2d');
    ctx.setTransform(dpr,0,0,dpr,0,0);
    draw(ctx,r.width,r.height,t);
  }

  return {
    start(){
      if(_alive)return;
      _alive=true; _t0=performance.now(); _loopCount=0; _tapFlash=0;
      _eyeTrackX=0; _eyeTrackY=0;
      _raf=requestAnimationFrame(loop);
      // Tap/click: ripple + flash the maze eye
      const cv=document.getElementById('heroV4Canvas');
      if(cv&&!cv._tapBound){
        cv._tapBound=true;
        cv.addEventListener('pointerdown',e=>{
          if(!_alive)return;
          const r=cv.getBoundingClientRect();
          _tapX=(e.clientX-r.left)*(cv.width/r.width/Math.min(window.devicePixelRatio||1,3));
          _tapY=(e.clientY-r.top)*(cv.height/r.height/Math.min(window.devicePixelRatio||1,3));
          _tapFlash=performance.now();
        });
      }
    },
    stop(){_alive=false;if(_raf)cancelAnimationFrame(_raf);const cv=document.getElementById('heroV4Canvas');if(cv){const ctx=cv.getContext('2d');ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,cv.width,cv.height);}},
    restart(){this.stop();setTimeout(()=>this.start(),50);}
  };
})();
