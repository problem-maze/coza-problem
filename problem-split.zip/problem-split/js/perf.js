const perf={
  isLowEnd:false,
  isMidTier:false,
  isHighEnd:false,
  isMobile:false,
  isVisible:true,
  prefersReducedMotion:false,
  tier:'high' // 'high' | 'mid' | 'low'
};
window.perf = perf;  // expose for canvas engines (V3/V4/V5)
(function detectPerf(){
  const ua=navigator.userAgent;
  perf.isMobile=/Android|iPhone|iPad|iPod|Mobile|Tablet/i.test(ua);
  
  // Hardware specs
  const cores=navigator.hardwareConcurrency||2;
  const mem=navigator.deviceMemory||4;
  const smallScreen=innerWidth<768;
  const verySmallScreen=innerWidth<400;
  
  // Old browser detection (no modern features = older device)
  const isOldBrowser=!('IntersectionObserver' in window)||!('ResizeObserver' in window);
  
  // iOS detection (some older iOS devices need lite tier)
  const isIOS=/iPhone|iPad|iPod/.test(ua);
  // Get iOS version (rough estimate)
  let iosOld=false;
  if(isIOS){
    const m=ua.match(/OS (\d+)_/);
    if(m&&parseInt(m[1])<13)iosOld=true;
  }
  
  // ── NETWORK SPEED DETECTION ──
  // navigator.connection (Network Information API) is available on most
  // mobile browsers. Slow connections (2G/3G or saveData mode) signal
  // a constrained device — downgrade to low tier even if hardware is OK.
  let isSlowNetwork = false;
  let saveDataMode = false;
  try {
    const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    if(conn){
      // effectiveType: 'slow-2g', '2g', '3g', '4g'
      if(conn.effectiveType && /^(slow-2g|2g|3g)$/.test(conn.effectiveType)){
        isSlowNetwork = true;
      }
      // User has Data Saver enabled
      if(conn.saveData === true){
        saveDataMode = true;
      }
      // Very low downlink (< 1.5 Mbps)
      if(typeof conn.downlink === 'number' && conn.downlink > 0 && conn.downlink < 1.5){
        isSlowNetwork = true;
      }
    }
  } catch(e){}
  perf.slowNetwork = isSlowNetwork;
  perf.saveData = saveDataMode;

  // ── 3-TIER PERFORMANCE CLASSIFICATION ──
  // LOW tier: very weak devices OR slow network OR data-saver
  if(
    isOldBrowser ||
    iosOld ||
    isSlowNetwork ||
    saveDataMode ||
    (perf.isMobile && (cores<=2 || mem<=2)) ||
    (perf.isMobile && verySmallScreen && cores<=4)
  ){
    perf.tier='low';
    perf.isLowEnd=true;
  }
  // MID tier: average mobile devices
  else if(
    perf.isMobile && (cores<=4 || mem<=4 || smallScreen)
  ){
    perf.tier='mid';
    perf.isMidTier=true;
  }
  // HIGH tier: desktop or strong mobile
  else{
    perf.tier='high';
    perf.isHighEnd=true;
  }
  
  // Reduced motion preference (accessibility)
  try{perf.prefersReducedMotion=matchMedia('(prefers-reduced-motion:reduce)').matches}catch(e){}
  
  // Apply CSS classes for styling targeting
  const html=document.documentElement;
  html.classList.add('tier-'+perf.tier);
  if(perf.isLowEnd)html.classList.add('low-end');
  if(perf.isMidTier)html.classList.add('mid-tier');
  if(perf.isMobile)html.classList.add('is-mobile');
  if(perf.prefersReducedMotion)html.classList.add('reduced-motion');
  
  // Adaptive FPS check (after page loads, measure actual frame rate)
  let frameCount=0,startTime=performance.now();
  function measureFPS(){
    frameCount++;
    if(frameCount<30){
      requestAnimationFrame(measureFPS);
    }else{
      const elapsed=performance.now()-startTime;
      const fps=(frameCount/elapsed)*1000;
      // If FPS drops below 30, downgrade tier
      if(fps<30 && perf.tier==='high'){
        perf.tier='mid';
        perf.isMidTier=true;
        perf.isHighEnd=false;
        html.classList.remove('tier-high');
        html.classList.add('tier-mid','mid-tier');
        console.log('[perf] Downgraded high→mid (FPS:',fps.toFixed(0),')');
      }else if(fps<20 && perf.tier==='mid'){
        perf.tier='low';
        perf.isLowEnd=true;
        perf.isMidTier=false;
        html.classList.remove('tier-mid','mid-tier');
        html.classList.add('tier-low','low-end');
        console.log('[perf] Downgraded mid→low (FPS:',fps.toFixed(0),')');
      }
    }
  }
  setTimeout(()=>{startTime=performance.now();frameCount=0;requestAnimationFrame(measureFPS)},2000);
})();

// ── Battery API — downgrade on low battery ──────────────────
(function detectBattery(){
  if(!navigator.getBattery) return;
  navigator.getBattery().then(b => {
    function applyBattery(){
      // low battery (< 20%) and NOT charging = save power
      const savePower = b.level < 0.20 && !b.charging;
      const html = document.documentElement;
      if(savePower && perf.tier !== 'low'){
        perf.tier = 'low';
        perf.isLowEnd = true;
        perf.isMidTier = false;
        html.classList.remove('tier-high','tier-mid','mid-tier');
        html.classList.add('tier-low','low-end');
        console.log('[perf] Battery low ('+Math.round(b.level*100)+'%) → tier-low');
      }
    }
    applyBattery();
    b.addEventListener('levelchange',  applyBattery);
    b.addEventListener('chargingchange', applyBattery);
  }).catch(()=>{});
})();

// ── Re-check FPS every 30s — downgrade if device struggles ──
(function livePerf(){
  const html = document.documentElement;
  let fc = 0, st = 0, running = false;

  function measure(){
    fc++;
    if(fc < 60){
      requestAnimationFrame(measure);
    } else {
      const fps = (fc / (performance.now() - st)) * 1000;
      running = false;

      // Downgrade
      if(fps < 25 && perf.tier === 'high'){
        perf.tier='mid'; perf.isMidTier=true; perf.isHighEnd=false;
        html.classList.replace('tier-high','tier-mid');
        html.classList.add('mid-tier');
        console.log('[perf] Live: high→mid ('+fps.toFixed(0)+'fps)');
      } else if(fps < 20 && perf.tier === 'mid'){
        perf.tier='low'; perf.isLowEnd=true; perf.isMidTier=false;
        html.classList.remove('tier-mid','mid-tier');
        html.classList.add('tier-low','low-end');
        console.log('[perf] Live: mid→low ('+fps.toFixed(0)+'fps)');

      // Upgrade — device recovered
      } else if(fps > 55 && perf.tier === 'low'){
        perf.tier='mid'; perf.isLowEnd=false; perf.isMidTier=true;
        html.classList.replace('tier-low','tier-mid');
        html.classList.remove('low-end'); html.classList.add('mid-tier');
        console.log('[perf] Live: low→mid ('+fps.toFixed(0)+'fps)');
      } else if(fps > 58 && perf.tier === 'mid'){
        perf.tier='high'; perf.isMidTier=false; perf.isHighEnd=true;
        html.classList.replace('tier-mid','tier-high');
        html.classList.remove('mid-tier');
        console.log('[perf] Live: mid→high ('+fps.toFixed(0)+'fps)');
      }
    }
  }

  // Run every 30s — only when tab visible and not already measuring
  setInterval(()=>{
    if(!perf.isVisible || running) return;
    running = true; fc = 0; st = performance.now();
    requestAnimationFrame(measure);
  }, 30000);
})();

// ── prefers-reduced-motion — respect system accessibility ────
(function detectReducedMotion(){
  const html = document.documentElement;
  const mq = window.matchMedia('(prefers-reduced-motion: reduce)');

  function apply(reduced){
    perf.prefersReducedMotion = reduced;
    if(reduced){
      html.classList.add('reduced-motion');
      if(perf.tier !== 'low'){
        perf.tier = 'low'; perf.isLowEnd = true; perf.isMidTier = false;
        html.classList.remove('tier-high','tier-mid','mid-tier');
        html.classList.add('tier-low','low-end');
        console.log('[perf] reduced-motion → tier-low');
      }
    } else {
      html.classList.remove('reduced-motion');
    }
  }

  apply(mq.matches);
  mq.addEventListener('change', e => apply(e.matches));
})();

// Tab visibility — pause animations when tab is hidden
// FIX v76: debounce the "invisible" state so iOS/Android browser-chrome
// show/hide gestures don't kill animations on every touch.
// Becoming visible is instant; becoming invisible waits 600ms to confirm.
(function(){
  let _hideTimer=null;
  document.addEventListener('visibilitychange',()=>{
    if(!document.hidden){
      // Immediately resume
      clearTimeout(_hideTimer);
      perf.isVisible=true;
      // HeroLife: رجّع الأنيميشن المختار لما التطبيق يرجع للمقدمة
      if(window.HeroLife) window.HeroLife.setVisible(true);
    } else {
      // Delay pause — browser-chrome flickers last <200ms on mobile
      clearTimeout(_hideTimer);
      _hideTimer=setTimeout(()=>{ perf.isVisible=false; },600);
      // HeroLife: أوقف الأنيميشن فوراً لما التطبيق يروح الخلفية (توفير بطارية)
      if(window.HeroLife) window.HeroLife.setVisible(false);
    }
  });
})();

// ═══ Theme is dark-only — forced before any paint ═══
try{
  document.documentElement.removeAttribute('data-theme');
  localStorage.removeItem('theme');
  localStorage.removeItem('themeManual');
}catch(e){}

// === STORAGE FALLBACK (for environments where localStorage is blocked) ===
