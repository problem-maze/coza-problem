const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

// Serve static files
app.use(express.static(path.join(__dirname)));

// Headers مهمة لأداء الموبايل
app.use((req, res, next) => {
  // Cache engines for 1 hour (مش بتتغير كتير)
  if (req.path.startsWith('/js/engines/')) {
    res.setHeader('Cache-Control', 'public, max-age=3600');
  }
  // CSS cache
  if (req.path.startsWith('/css/')) {
    res.setHeader('Cache-Control', 'public, max-age=3600');
  }
  next();
});

app.listen(PORT, () => {
  console.log(`\n✓ Server running on http://localhost:${PORT}`);
  console.log(`  افتح المتصفح على: http://localhost:${PORT}\n`);
});
